import type { Config } from 'tailwindcss';
export default { content: ['./src/**/*.{js,ts,jsx,tsx,mdx}'], theme: { extend: { colors: { land: { 950: '#063b28', 900: '#075333', 700: '#08764a', 100: '#e8f2eb', gold: '#d9b85b' } } } }, plugins: [] } satisfies Config;
