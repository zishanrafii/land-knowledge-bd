import { pgTable, pgEnum, uuid, text, varchar, timestamp, date, integer, boolean, jsonb, index, uniqueIndex } from 'drizzle-orm/pg-core';

export const adminRole = pgEnum('admin_role', ['SUPER_ADMIN','EDITOR','REVIEWER']);

export const verificationStatus = pgEnum('verification_status', ['PENDING','PARTIALLY_VERIFIED','VERIFIED','INCORRECT_REPLACED','DUPLICATE']);
export const documentType = pgEnum('document_type', ['ACT','ORDINANCE','RULE','REGULATION','POLICY','GAZETTE','CIRCULAR','NOTIFICATION','MANUAL','GUIDELINE','COURT_JUDGMENT','OTHER']);
export const legalDocuments = pgTable('legal_documents', {
  id: uuid('id').defaultRandom().primaryKey(),
  slug: varchar('slug',{length:180}).notNull(),
  titleBn: text('title_bn').notNull(),
  titleEn: text('title_en'),
  documentType: documentType('document_type').notNull(),
  documentNumber: varchar('document_number',{length:100}),
  publicationDate: date('publication_date'),
  commencementDate: date('commencement_date'),
  jurisdiction: varchar('jurisdiction',{length:120}).default('Bangladesh').notNull(),
  summaryBn: text('summary_bn'),
  summaryEn: text('summary_en'),
  status: verificationStatus('verification_status').default('PENDING').notNull(),
  isRepealed: boolean('is_repealed').default(false).notNull(),
  createdAt: timestamp('created_at',{withTimezone:true}).defaultNow().notNull(),
  updatedAt: timestamp('updated_at',{withTimezone:true}).defaultNow().notNull(),
}, t => ({ slugUnique: uniqueIndex('legal_documents_slug_uq').on(t.slug), statusIdx: index('legal_documents_status_idx').on(t.status) }));

export const legalVersions = pgTable('legal_versions', {
  id: uuid('id').defaultRandom().primaryKey(),
  documentId: uuid('document_id').references(()=>legalDocuments.id,{onDelete:'cascade'}).notNull(),
  versionLabel: varchar('version_label',{length:160}).notNull(),
  effectiveFrom: date('effective_from'),
  effectiveTo: date('effective_to'),
  sourceNote: text('source_note'),
  sourceUrl: text('source_url'),
  originalFileUrl: text('original_file_url'),
  checksum: varchar('checksum',{length:128}),
  createdAt: timestamp('created_at',{withTimezone:true}).defaultNow().notNull(),
}, t => ({ documentIdx: index('legal_versions_document_idx').on(t.documentId) }));

export const legalSections = pgTable('legal_sections', {
  id: uuid('id').defaultRandom().primaryKey(),
  versionId: uuid('version_id').references(()=>legalVersions.id,{onDelete:'cascade'}).notNull(),
  sectionNumber: varchar('section_number',{length:80}).notNull(),
  headingBn: text('heading_bn'),
  headingEn: text('heading_en'),
  bodyBn: text('body_bn'),
  bodyEn: text('body_en'),
  sortOrder: integer('sort_order').default(0).notNull(),
}, t => ({ versionIdx: index('legal_sections_version_idx').on(t.versionId) }));

export const officialSources = pgTable('official_sources', {
  id: uuid('id').defaultRandom().primaryKey(),
  documentId: uuid('document_id').references(()=>legalDocuments.id,{onDelete:'cascade'}).notNull(),
  authority: varchar('authority',{length:220}).notNull(),
  sourceUrl: text('source_url').notNull(),
  sourceKind: varchar('source_kind',{length:80}).notNull(),
  checkedAt: timestamp('checked_at',{withTimezone:true}),
  isPrimary: boolean('is_primary').default(true).notNull(),
});

export const amendments = pgTable('amendments', {
  id: uuid('id').defaultRandom().primaryKey(),
  baseDocumentId: uuid('base_document_id').references(()=>legalDocuments.id).notNull(),
  amendingDocumentId: uuid('amending_document_id').references(()=>legalDocuments.id).notNull(),
  affectedSections: jsonb('affected_sections').$type<string[]>(),
  effectiveDate: date('effective_date'),
  changeSummaryBn: text('change_summary_bn'),
});

export const courtCases = pgTable('court_cases', {
  id: uuid('id').defaultRandom().primaryKey(),
  slug: varchar('slug',{length:200}).notNull(),
  caseTitle: text('case_title').notNull(),
  caseNumber: varchar('case_number',{length:180}),
  court: varchar('court',{length:180}).notNull(),
  courtDivision: varchar('court_division',{length:80}),
  bench: text('bench'),
  caseType: varchar('case_type',{length:120}),
  judgmentDate: date('judgment_date'),
  decisionType: varchar('decision_type',{length:80}),
  decisionStatus: varchar('decision_status',{length:80}),
  summaryBn: text('summary_bn'),
  summaryEn: text('summary_en'),
  judgmentTextBn: text('judgment_text_bn'),
  officialUrl: text('official_url'),
  status: verificationStatus('verification_status').default('PENDING').notNull(),
  createdAt: timestamp('created_at',{withTimezone:true}).defaultNow().notNull(),
  updatedAt: timestamp('updated_at',{withTimezone:true}).defaultNow().notNull(),
}, t => ({ courtIdx: index('court_cases_court_idx').on(t.court), caseSlugUnique: uniqueIndex('court_cases_slug_uq').on(t.slug), caseStatusIdx: index('court_cases_status_idx').on(t.status) }));

export const caseAttachments = pgTable('case_attachments', {
  id: uuid('id').defaultRandom().primaryKey(),
  caseId: uuid('case_id').references(()=>courtCases.id,{onDelete:'cascade'}).notNull(),
  title: text('title').notNull(),
  fileUrl: text('file_url').notNull(),
  mimeType: varchar('mime_type',{length:120}),
  sourceAuthority: varchar('source_authority',{length:220}),
  checksum: varchar('checksum',{length:128}),
  createdAt: timestamp('created_at',{withTimezone:true}).defaultNow().notNull(),
}, t => ({ caseIdx: index('case_attachments_case_idx').on(t.caseId) }));

export const caseSources = pgTable('case_sources', {
  id: uuid('id').defaultRandom().primaryKey(),
  caseId: uuid('case_id').references(()=>courtCases.id,{onDelete:'cascade'}).notNull(),
  authority: varchar('authority',{length:220}).notNull(),
  sourceUrl: text('source_url').notNull(),
  sourceKind: varchar('source_kind',{length:80}).notNull(),
  checkedAt: timestamp('checked_at',{withTimezone:true}),
  isPrimary: boolean('is_primary').default(true).notNull(),
}, t => ({ caseIdx: index('case_sources_case_idx').on(t.caseId) }));

export const caseLegalLinks = pgTable('case_legal_links', {
  id: uuid('id').defaultRandom().primaryKey(),
  caseId: uuid('case_id').references(()=>courtCases.id,{onDelete:'cascade'}).notNull(),
  documentId: uuid('document_id').references(()=>legalDocuments.id,{onDelete:'cascade'}).notNull(),
  sectionNumber: varchar('section_number',{length:80}),
  relationNoteBn: text('relation_note_bn'),
}, t => ({ caseIdx: index('case_legal_links_case_idx').on(t.caseId), documentIdx: index('case_legal_links_document_idx').on(t.documentId) }));

export const verificationRecords = pgTable('verification_records', {
  id: uuid('id').defaultRandom().primaryKey(),
  entityType: varchar('entity_type',{length:60}).notNull(),
  entityId: uuid('entity_id').notNull(),
  status: verificationStatus('verification_status').notNull(),
  checkedBy: varchar('checked_by',{length:180}),
  checkedAt: timestamp('checked_at',{withTimezone:true}).defaultNow().notNull(),
  notes: text('notes'),
});

export const categories = pgTable('legal_categories', {
  id: uuid('id').defaultRandom().primaryKey(),
  slug: varchar('slug',{length:120}).notNull().unique(),
  nameBn: varchar('name_bn',{length:220}).notNull(),
  nameEn: varchar('name_en',{length:220}),
  parentId: uuid('parent_id'),
  sortOrder: integer('sort_order').default(0).notNull(),
});


export const sourceAttachments = pgTable('source_attachments', {
  id: uuid('id').defaultRandom().primaryKey(),
  documentId: uuid('document_id').references(()=>legalDocuments.id,{onDelete:'cascade'}).notNull(),
  title: text('title').notNull(),
  fileUrl: text('file_url').notNull(),
  mimeType: varchar('mime_type',{length:120}),
  fileSizeBytes: integer('file_size_bytes'),
  sha256: varchar('sha256',{length:64}),
  sourceType: varchar('source_type',{length:80}).notNull(),
  uploadedAt: timestamp('uploaded_at',{withTimezone:true}).defaultNow().notNull(),
  uploadedBy: varchar('uploaded_by',{length:254}),
});


export const adminUsers = pgTable('admin_users', {
  id: uuid('id').defaultRandom().primaryKey(),
  email: varchar('email', { length: 254 }).notNull().unique(),
  passwordHash: text('password_hash').notNull(),
  role: adminRole('role').default('EDITOR').notNull(),
  isActive: boolean('is_active').default(true).notNull(),
  createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp('updated_at', { withTimezone: true }).defaultNow().notNull(),
});

export const caseResearchNotes = pgTable('case_research_notes', {
  id: uuid('id').defaultRandom().primaryKey(),
  caseId: uuid('case_id').references(() => courtCases.id, { onDelete: 'cascade' }).notNull(),
  note: text('note').notNull(),
  noteType: varchar('note_type', { length: 60 }).default('RESEARCH').notNull(),
  visibility: varchar('visibility', { length: 30 }).default('INTERNAL').notNull(),
  createdBy: varchar('created_by', { length: 254 }),
  createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
}, t => ({ caseIdx: index('case_research_notes_case_idx').on(t.caseId) }));


// Persistent per-email login throttling. Apply the Phase 9 SQL migration before use.
export const adminLoginAttempts = pgTable('admin_login_attempts', {
  id: uuid('id').defaultRandom().primaryKey(),
  email: varchar('email', { length: 254 }).notNull().unique(),
  failedAttempts: integer('failed_attempts').default(0).notNull(),
  windowStartedAt: timestamp('window_started_at', { withTimezone: true }).defaultNow().notNull(),
  lockedUntil: timestamp('locked_until', { withTimezone: true }),
  updatedAt: timestamp('updated_at', { withTimezone: true }).defaultNow().notNull(),
});
