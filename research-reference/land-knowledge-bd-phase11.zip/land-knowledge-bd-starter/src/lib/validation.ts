import { z } from 'zod';

export const httpsUrl = z.string().url().refine((value) => {
  try { return new URL(value).protocol === 'https:'; } catch { return false; }
}, 'শুধু HTTPS URL গ্রহণযোগ্য।');

export const legalDocumentInput = z.object({
  slug: z.string().min(2).max(180).regex(/^[a-z0-9-]+$/),
  titleBn: z.string().min(2),
  titleEn: z.string().optional(),
  documentType: z.enum(['ACT','ORDINANCE','RULE','REGULATION','POLICY','GAZETTE','CIRCULAR','NOTIFICATION','MANUAL','GUIDELINE','COURT_JUDGMENT','OTHER']),
  documentNumber: z.string().max(100).optional(),
  publicationDate: z.string().date().optional(),
  commencementDate: z.string().date().optional(),
  sourceUrl: httpsUrl.optional(),
});
