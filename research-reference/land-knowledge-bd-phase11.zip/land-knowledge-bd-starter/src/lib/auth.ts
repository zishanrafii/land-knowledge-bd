import 'server-only';

import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { SignJWT, jwtVerify } from 'jose';
import { and, eq } from 'drizzle-orm';
import { db } from '@/db';
import { adminUsers } from '@/db/schema';

export type AdminRole = 'SUPER_ADMIN' | 'EDITOR' | 'REVIEWER';
export type AdminSession = { userId: string; email: string; role: AdminRole };

const COOKIE_NAME = 'lkbd_admin_session';
const SESSION_SECONDS = 60 * 60 * 8;

function secretKey() {
  const secret = process.env.ADMIN_SESSION_SECRET;
  if (!secret || new TextEncoder().encode(secret).length < 32) {
    throw new Error('ADMIN_SESSION_SECRET must be configured with at least 32 characters.');
  }
  return new TextEncoder().encode(secret);
}

export async function createAdminSession(user: AdminSession) {
  const token = await new SignJWT({ email: user.email, role: user.role })
    .setProtectedHeader({ alg: 'HS256' })
    .setSubject(user.userId)
    .setIssuedAt()
    .setExpirationTime(`${SESSION_SECONDS}s`)
    .sign(secretKey());

  const jar = await cookies();
  jar.set(COOKIE_NAME, token, {
    httpOnly: true, secure: process.env.NODE_ENV === 'production',
    sameSite: 'strict', path: '/', maxAge: SESSION_SECONDS,
  });
}

export async function clearAdminSession() {
  const jar = await cookies();
  jar.set(COOKIE_NAME, '', { httpOnly: true, secure: process.env.NODE_ENV === 'production',
    sameSite: 'strict', path: '/', maxAge: 0 });
}

export async function getAdminSession(): Promise<AdminSession | null> {
  const jar = await cookies();
  const token = jar.get(COOKIE_NAME)?.value;
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, secretKey());
    if (!payload.sub || typeof payload.email !== 'string' ||
        !['SUPER_ADMIN', 'EDITOR', 'REVIEWER'].includes(String(payload.role))) return null;

    // Re-check the account on every request so disabled users/changed roles lose access.
    const [user] = await db.select({
      id: adminUsers.id, email: adminUsers.email, role: adminUsers.role,
    }).from(adminUsers).where(and(
      eq(adminUsers.id, payload.sub), eq(adminUsers.isActive, true),
    )).limit(1);
    if (!user) return null;
    return { userId: user.id, email: user.email, role: user.role };
  } catch {
    return null;
  }
}

export async function requireAdmin(roles?: AdminRole[]) {
  const session = await getAdminSession();
  if (!session) return null;
  if (roles && !roles.includes(session.role)) return null;
  return session;
}

export async function requireAdminPage(roles?: AdminRole[]) {
  const session = await getAdminSession();
  if (!session) redirect('/admin/login');
  if (roles && !roles.includes(session.role)) redirect('/admin');
  return session;
}
