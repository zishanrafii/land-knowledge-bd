import Link from 'next/link';
import { and, asc, eq } from 'drizzle-orm';
import { notFound } from 'next/navigation';
import { db } from '@/db';
import { legalDocuments, legalVersions, legalSections, officialSources, sourceAttachments } from '@/db/schema';

export default async function LawDetail({ params }: { params: Promise<{slug:string}> }) {
  const {slug}=await params;
  const [doc]=await db.select().from(legalDocuments).where(and(eq(legalDocuments.slug,slug),eq(legalDocuments.status,'VERIFIED'),eq(legalDocuments.isRepealed,false))).limit(1);
  if(!doc) notFound();
  const versions=await db.select().from(legalVersions).where(eq(legalVersions.documentId,doc.id)).orderBy(asc(legalVersions.effectiveFrom));
  const sources=await db.select().from(officialSources).where(eq(officialSources.documentId,doc.id));
  const attachments=await db.select().from(sourceAttachments).where(eq(sourceAttachments.documentId,doc.id));
  const sections=versions.length ? await db.select().from(legalSections).where(eq(legalSections.versionId,versions[versions.length-1].id)).orderBy(asc(legalSections.sortOrder)) : [];
  return <main className="mx-auto min-h-screen max-w-4xl px-5 py-12">
    <Link href="/laws" className="text-sm text-emerald-800">← আইনভান্ডার</Link>
    <div className="mt-5 flex flex-wrap gap-2"><span className="rounded-full bg-slate-100 px-3 py-1 text-xs">{doc.documentType}</span><span className="rounded-full bg-emerald-50 px-3 py-1 text-xs text-emerald-800">যাচাইকৃত</span></div>
    <h1 className="mt-4 text-3xl font-bold">{doc.titleBn}</h1>
    {doc.titleEn&&<p className="mt-2 text-lg text-slate-500">{doc.titleEn}</p>}
    <dl className="mt-6 grid gap-3 rounded-2xl border bg-white p-5 sm:grid-cols-2">
      <div><dt className="text-xs text-slate-500">নথি নম্বর</dt><dd>{doc.documentNumber||'উল্লেখ নেই'}</dd></div>
      <div><dt className="text-xs text-slate-500">প্রকাশের তারিখ</dt><dd>{doc.publicationDate||'উল্লেখ নেই'}</dd></div>
      <div><dt className="text-xs text-slate-500">কার্যকারিতার তারিখ</dt><dd>{doc.commencementDate||'উল্লেখ নেই'}</dd></div>
      <div><dt className="text-xs text-slate-500">এলাকা</dt><dd>{doc.jurisdiction}</dd></div>
    </dl>
    {doc.summaryBn&&<section className="mt-8"><h2 className="text-xl font-bold">সংক্ষিপ্ত বিবরণ</h2><p className="mt-2 leading-7 text-slate-700">{doc.summaryBn}</p></section>}
    <section className="mt-9"><h2 className="text-xl font-bold">সরকারি উৎস</h2>{sources.length? <ul className="mt-3 space-y-3">{sources.map(s=><li key={s.id} className="rounded-xl border bg-white p-4"><p className="font-semibold">{s.authority}</p><p className="text-xs text-slate-500">{s.sourceKind}</p><a href={s.sourceUrl} target="_blank" rel="noreferrer" className="mt-1 block break-all text-sm text-emerald-800 underline">মূল উৎস খুলুন</a></li>)}</ul>:<p className="mt-2 text-sm text-slate-600">প্রকাশিত নথির জন্য উৎস রেকর্ড প্রস্তুত করা হচ্ছে।</p>}</section>
    {attachments.length>0&&<section className="mt-8"><h2 className="text-xl font-bold">মূল PDF / সংযুক্ত নথি</h2><ul className="mt-3 space-y-2">{attachments.map(a=><li key={a.id}><a href={a.fileUrl} target="_blank" rel="noreferrer" className="text-emerald-800 underline">{a.title}</a></li>)}</ul></section>}
    {versions.length>0&&<section className="mt-8"><h2 className="text-xl font-bold">সংস্করণ ও কার্যকারিতা</h2><div className="mt-3 space-y-3">{versions.map(v=><div key={v.id} className="rounded-xl border bg-white p-4"><p className="font-semibold">{v.versionLabel}</p><p className="mt-1 text-sm text-slate-600">{v.effectiveFrom||'তারিখ নেই'} — {v.effectiveTo||'বর্তমান/শেষ তারিখ অনির্দিষ্ট'}</p>{v.sourceUrl&&<a href={v.sourceUrl} target="_blank" rel="noreferrer" className="text-sm text-emerald-800 underline">সংস্করণের উৎস</a>}</div>)}</div></section>}
    <section className="mt-8"><h2 className="text-xl font-bold">ধারা</h2>{sections.length? <div className="mt-3 space-y-4">{sections.map(s=><article key={s.id} className="rounded-xl border bg-white p-5"><h3 className="font-bold">ধারা {s.sectionNumber}{s.headingBn?` — ${s.headingBn}`:''}</h3>{s.bodyBn&&<p className="mt-3 whitespace-pre-wrap leading-7 text-slate-700">{s.bodyBn}</p>}{s.bodyEn&&<p className="mt-3 whitespace-pre-wrap border-t pt-3 text-sm leading-6 text-slate-600">{s.bodyEn}</p>}</article>)}</div>:<p className="mt-2 text-sm text-slate-600">ধারাভিত্তিক পূর্ণ পাঠ এখনো যুক্ত হয়নি। মূল সরকারি উৎস দেখুন।</p>}</section>
    <p className="mt-10 rounded-xl bg-amber-50 p-4 text-sm leading-6 text-amber-900">আইন প্রয়োগের আগে মূল সরকারি গেজেট ও সর্বশেষ সংশোধনী যাচাই করুন। এই তথ্য সাধারণ আইনি শিক্ষার জন্য; ব্যক্তিগত মামলার আইনি পরামর্শ নয়।</p>
  </main>;
}
