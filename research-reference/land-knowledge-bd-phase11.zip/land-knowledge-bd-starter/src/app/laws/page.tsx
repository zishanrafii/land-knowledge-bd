import Link from 'next/link';
import { and, asc, eq, ilike, or } from 'drizzle-orm';
import { db } from '@/db';
import { legalDocuments } from '@/db/schema';

const types = ['ACT','ORDINANCE','RULE','REGULATION','POLICY','GAZETTE','CIRCULAR','NOTIFICATION','MANUAL','GUIDELINE','COURT_JUDGMENT','OTHER'];
const labels: Record<string,string> = { ACT:'আইন', ORDINANCE:'অধ্যাদেশ', RULE:'বিধিমালা', REGULATION:'প্রবিধান', POLICY:'নীতিমালা', GAZETTE:'গেজেট', CIRCULAR:'পরিপত্র', NOTIFICATION:'প্রজ্ঞাপন', MANUAL:'ম্যানুয়াল', GUIDELINE:'নির্দেশিকা', COURT_JUDGMENT:'আদালতের রায়', OTHER:'অন্যান্য' };

export default async function LawsPage({ searchParams }: { searchParams: Promise<{q?:string; type?:string; status?:string}> }) {
  const params = await searchParams;
  const q = (params.q || '').trim().slice(0,120);
  const type = types.includes(params.type || '') ? params.type! : '';
  const conditions = [eq(legalDocuments.status,'VERIFIED'), eq(legalDocuments.isRepealed,false)];
  if (type) conditions.push(eq(legalDocuments.documentType, type as typeof legalDocuments.$inferSelect.documentType));
  if (q) conditions.push(or(ilike(legalDocuments.titleBn, `%${q}%`), ilike(legalDocuments.titleEn, `%${q}%`), ilike(legalDocuments.documentNumber, `%${q}%`))!);
  let docs: Array<typeof legalDocuments.$inferSelect> = [];
  let dbReady = true;
  try { docs = await db.select().from(legalDocuments).where(and(...conditions)).orderBy(asc(legalDocuments.titleBn)).limit(100); }
  catch { dbReady = false; }

  return <main className="mx-auto min-h-screen max-w-5xl px-5 py-12">
    <Link href="/" className="text-sm text-emerald-800">← হোম</Link>
    <h1 className="mt-5 text-3xl font-bold">আইন ও বিধিমালা</h1>
    <p className="mt-2 text-slate-600">শুধু যাচাইকৃত ও বর্তমানে কার্যকর হিসেবে চিহ্নিত নথি এখানে দেখানো হয়।</p>
    <form className="mt-6 grid gap-3 rounded-2xl border bg-white p-4 sm:grid-cols-[1fr_220px_auto]">
      <input name="q" defaultValue={q} placeholder="আইনের নাম, ইংরেজি নাম বা নম্বর লিখুন" className="rounded-lg border px-3 py-2"/>
      <select name="type" defaultValue={type} className="rounded-lg border px-3 py-2"><option value="">সব ধরনের নথি</option>{types.map(t=><option key={t} value={t}>{labels[t]}</option>)}</select>
      <button className="rounded-lg bg-emerald-800 px-5 py-2 font-semibold text-white">খুঁজুন</button>
    </form>
    {!dbReady ? <p className="mt-6 rounded-xl border border-amber-300 bg-amber-50 p-4 text-sm text-amber-900">ডেটাবেস সংযোগ বা migration প্রস্তুত নয়।</p> :
      docs.length===0 ? <p className="mt-6 rounded-xl border bg-white p-6 text-slate-600">এই অনুসন্ধানে যাচাইকৃত নথি পাওয়া যায়নি। নতুন নথি যাচাই শেষ হলে এখানে প্রকাশিত হবে।</p> :
      <div className="mt-6 divide-y rounded-2xl border bg-white">{docs.map(d=><article key={d.id} className="p-5">
        <div className="flex flex-wrap gap-2"><span className="rounded-full bg-slate-100 px-2 py-1 text-xs">{labels[d.documentType] || d.documentType}</span><span className="rounded-full bg-emerald-50 px-2 py-1 text-xs text-emerald-800">যাচাইকৃত</span></div>
        <h2 className="mt-2 font-semibold"><Link className="hover:underline" href={`/laws/${d.slug}`}>{d.titleBn}</Link></h2>
        {d.titleEn && <p className="text-sm text-slate-500">{d.titleEn}</p>}
        {d.documentNumber && <p className="mt-1 text-xs text-slate-500">নম্বর: {d.documentNumber}</p>}
        {d.summaryBn && <p className="mt-3 text-sm leading-6 text-slate-700">{d.summaryBn}</p>}
        <Link href={`/laws/${d.slug}`} className="mt-3 inline-block text-sm font-semibold text-emerald-800">বিস্তারিত পড়ুন →</Link>
      </article>)}</div>
    }
  </main>;
}
