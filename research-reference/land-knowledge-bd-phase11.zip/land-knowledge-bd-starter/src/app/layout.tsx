import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'ভূমি জ্ঞান | Land Knowledge BD',
  description: 'বাংলাদেশের ভূমি আইন, দলিল, রেকর্ড ও বিচারিক সিদ্ধান্তের তথ্যভান্ডার।',
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="bn"><body>{children}</body></html>;
}
