export default function UpdatesPage() {
  return <main className="mx-auto min-h-screen max-w-5xl px-5 py-12"><a href="/" className="text-sm text-emerald-800">← হোম</a><h1 className="mt-5 text-3xl font-bold">আইন পরিবর্তনের খবর</h1><p className="mt-3 text-slate-600">নতুন গেজেট, সংশোধনী, প্রজ্ঞাপন ও গুরুত্বপূর্ণ আদালতের সিদ্ধান্তের আপডেট এখানে প্রকাশিত হবে।</p></main>;
}
