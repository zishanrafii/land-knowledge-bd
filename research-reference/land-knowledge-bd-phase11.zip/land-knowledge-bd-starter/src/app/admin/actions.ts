'use server';

import { revalidatePath } from 'next/cache';
import { db } from '@/db';
import { legalDocuments, officialSources, verificationRecords } from '@/db/schema';
import { legalDocumentInput } from '@/lib/validation';
import { requireAdmin } from '@/lib/auth';

export async function createLegalDocument(formData: FormData) {
  const admin = await requireAdmin(['SUPER_ADMIN','EDITOR']);
  if (!admin) return { ok: false as const, message: 'অনুমতি নেই।' };

  const parsed = legalDocumentInput.safeParse({
    slug: formData.get('slug'), titleBn: formData.get('titleBn'),
    titleEn: formData.get('titleEn') || undefined,
    documentType: formData.get('documentType'),
    documentNumber: formData.get('documentNumber') || undefined,
    publicationDate: formData.get('publicationDate') || undefined,
    commencementDate: formData.get('commencementDate') || undefined,
    sourceUrl: formData.get('sourceUrl') || undefined,
  });
  if (!parsed.success) return { ok: false as const, message: 'তথ্য যাচাই হয়নি। প্রয়োজনীয় ঘরগুলো ঠিক করুন।' };

  const { sourceUrl, ...document } = parsed.data;
  const [created] = await db.insert(legalDocuments).values({ ...document, status: 'PENDING' }).returning({ id: legalDocuments.id });
  if (sourceUrl) {
    await db.insert(officialSources).values({ documentId: created.id, authority: 'উৎস যাচাই বাকি', sourceUrl, sourceKind: 'OFFICIAL_OR_PRIMARY_SOURCE', isPrimary: true });
  }
  await db.insert(verificationRecords).values({
    entityType: 'LEGAL_DOCUMENT', entityId: created.id, status: 'PENDING',
    checkedBy: admin.email, notes: 'নতুন নথি Admin intake form থেকে যোগ করা হয়েছে।',
  });
  revalidatePath('/laws');
  revalidatePath('/admin');
  return { ok: true as const, message: 'নথিটি Pending অবস্থায় সংরক্ষিত হয়েছে।' };
}
