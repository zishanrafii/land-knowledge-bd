import { redirect } from 'next/navigation';
import { asc, eq } from 'drizzle-orm';
import { db } from '@/db';
import { legalDocuments, officialSources, sourceAttachments } from '@/db/schema';
import { requireAdmin } from '@/lib/auth';
import { addOfficialSource } from './actions';

export default async function SourceAdminPage() {
  const admin = await requireAdmin(['SUPER_ADMIN','EDITOR']);
  if (!admin) redirect('/admin/login');
  const docs = await db.select({ id: legalDocuments.id, titleBn: legalDocuments.titleBn })
    .from(legalDocuments).orderBy(asc(legalDocuments.titleBn)).limit(300);
  const sources = await db.select({
    id: officialSources.id, authority: officialSources.authority,
    url: officialSources.sourceUrl, kind: officialSources.sourceKind,
    checkedAt: officialSources.checkedAt, title: legalDocuments.titleBn,
  }).from(officialSources).innerJoin(legalDocuments, eq(officialSources.documentId, legalDocuments.id))
    .orderBy(asc(legalDocuments.titleBn)).limit(300);
  const attachments = await db.select({
    title: sourceAttachments.title, url: sourceAttachments.fileUrl,
    documentTitle: legalDocuments.titleBn,
  }).from(sourceAttachments).innerJoin(legalDocuments, eq(sourceAttachments.documentId, legalDocuments.id)).limit(300);

  return <main className="mx-auto min-h-screen max-w-5xl px-5 py-10">
    <a href="/admin" className="text-sm text-emerald-800">← Admin</a>
    <h1 className="mt-5 text-3xl font-bold">সরকারি উৎস ও PDF ব্যবস্থাপনা</h1>
    <p className="mt-2 text-sm text-slate-600">এখানে URL metadata সংরক্ষণ করা হয়। URL যোগ করলেই ফাইলের সত্যতা বা সরকারি উৎসের বৈধতা যাচাই হয়ে যায় না।</p>
    <form action={addOfficialSource} className="mt-7 grid gap-4 rounded-2xl border bg-white p-6">
      <h2 className="font-bold">নতুন উৎস যোগ করুন</h2>
      <label className="grid gap-1 text-sm font-medium">আইন / নথি<select name="documentId" required className="rounded-lg border px-3 py-2 font-normal">{docs.map(d=><option key={d.id} value={d.id}>{d.titleBn}</option>)}</select></label>
      <label className="grid gap-1 text-sm font-medium">কর্তৃপক্ষ / উৎসের নাম<input name="authority" required className="rounded-lg border px-3 py-2 font-normal" placeholder="যেমন: বাংলাদেশ আইন মন্ত্রণালয়"/></label>
      <label className="grid gap-1 text-sm font-medium">সরকারি উৎসের URL<input name="sourceUrl" type="url" required className="rounded-lg border px-3 py-2 font-normal" placeholder="https://..."/></label>
      <label className="grid gap-1 text-sm font-medium">উৎসের ধরন<select name="sourceKind" className="rounded-lg border px-3 py-2 font-normal">{['OFFICIAL_LAW_PAGE','OFFICIAL_GAZETTE','OFFICIAL_PDF','COURT_JUDGMENT','MINISTRY_CIRCULAR','OTHER_PRIMARY_SOURCE'].map(v=><option key={v}>{v}</option>)}</select></label>
      <label className="grid gap-1 text-sm font-medium">PDF / সংযুক্ত নথির শিরোনাম (ঐচ্ছিক)<input name="attachmentTitle" className="rounded-lg border px-3 py-2 font-normal"/></label>
      <label className="grid gap-1 text-sm font-medium">PDF URL (ঐচ্ছিক)<input name="attachmentUrl" type="url" className="rounded-lg border px-3 py-2 font-normal" placeholder="https://..."/></label>
      <button className="justify-self-start rounded-xl bg-emerald-800 px-5 py-3 text-sm font-semibold text-white">Pending উৎস হিসেবে সংরক্ষণ</button>
    </form>
    <section className="mt-10"><h2 className="text-xl font-bold">সংরক্ষিত উৎস ({sources.length})</h2><div className="mt-3 divide-y rounded-2xl border bg-white">{sources.map(s=><div key={s.id} className="p-4"><p className="font-semibold">{s.title}</p><p className="text-xs text-slate-500">{s.authority} · {s.kind}</p><a href={s.url} target="_blank" rel="noreferrer" className="mt-1 block break-all text-sm text-emerald-800 underline">{s.url}</a><p className="mt-1 text-xs text-amber-700">যাচাইয়ের অবস্থা: Pending / যাচাই প্রয়োজন</p></div>)}</div></section>
    <section className="mt-10"><h2 className="text-xl font-bold">PDF / সংযুক্ত নথি ({attachments.length})</h2><div className="mt-3 divide-y rounded-2xl border bg-white">{attachments.map((a,i)=><div key={i} className="p-4"><p className="font-semibold">{a.documentTitle} — {a.title}</p><a href={a.url} target="_blank" rel="noreferrer" className="break-all text-sm text-emerald-800 underline">{a.url}</a></div>)}</div></section>
  </main>;
}
