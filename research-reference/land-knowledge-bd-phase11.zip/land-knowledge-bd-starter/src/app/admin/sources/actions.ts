'use server';

import { revalidatePath } from 'next/cache';
import { z } from 'zod';
import { db } from '@/db';
import { legalDocuments, officialSources, sourceAttachments, verificationRecords } from '@/db/schema';
import { requireAdmin } from '@/lib/auth';
import { httpsUrl } from '@/lib/validation';
import { eq } from 'drizzle-orm';

const sourceSchema = z.object({
  documentId: z.string().uuid(),
  authority: z.string().trim().min(2).max(220),
  sourceUrl: httpsUrl,
  sourceKind: z.enum(['OFFICIAL_LAW_PAGE','OFFICIAL_GAZETTE','OFFICIAL_PDF','COURT_JUDGMENT','MINISTRY_CIRCULAR','OTHER_PRIMARY_SOURCE']),
  attachmentTitle: z.string().trim().max(300).optional(),
  attachmentUrl: httpsUrl.optional().or(z.literal('')),
});

export async function addOfficialSource(formData: FormData) {
  const admin = await requireAdmin(['SUPER_ADMIN','EDITOR']);
  if (!admin) return { ok: false as const, message: 'অনুমতি নেই।' };

  const parsed = sourceSchema.safeParse({
    documentId: formData.get('documentId'),
    authority: formData.get('authority'),
    sourceUrl: formData.get('sourceUrl'),
    sourceKind: formData.get('sourceKind'),
    attachmentTitle: formData.get('attachmentTitle') || undefined,
    attachmentUrl: formData.get('attachmentUrl') || '',
  });
  if (!parsed.success) return { ok: false as const, message: 'তথ্য সঠিক নয়। URL ও প্রয়োজনীয় ঘর পরীক্ষা করুন।' };

  const [doc] = await db.select({ id: legalDocuments.id }).from(legalDocuments)
    .where(eq(legalDocuments.id, parsed.data.documentId)).limit(1);
  if (!doc) return { ok: false as const, message: 'আইন/নথিটি পাওয়া যায়নি।' };

  await db.transaction(async (tx) => {
    const [source] = await tx.insert(officialSources).values({
      documentId: doc.id,
      authority: parsed.data.authority,
      sourceUrl: parsed.data.sourceUrl,
      sourceKind: parsed.data.sourceKind,
      isPrimary: true,
    }).returning({ id: officialSources.id });

    if (parsed.data.attachmentUrl) {
      await tx.insert(sourceAttachments).values({
        documentId: doc.id,
        title: parsed.data.attachmentTitle || 'মূল নথি / PDF',
        fileUrl: parsed.data.attachmentUrl,
        sourceType: parsed.data.sourceKind,
        uploadedBy: admin.email,
      });
    }

    // A changed source set requires a fresh legal-document review.
    await tx.update(legalDocuments).set({
      status: 'PENDING',
      updatedAt: new Date(),
    }).where(eq(legalDocuments.id, doc.id));

    await tx.insert(verificationRecords).values({
      entityType: 'LEGAL_DOCUMENT',
      entityId: doc.id,
      status: 'PENDING',
      checkedBy: admin.email,
      notes: `নতুন সরকারি উৎস যুক্ত হয়েছে (source id: ${source.id}); URL ও ফাইলের সত্যতা পুনরায় যাচাই বাকি।`,
    });
  });

  revalidatePath('/admin/sources');
  revalidatePath('/laws');
  return { ok: true as const, message: 'উৎস Pending অবস্থায় যুক্ত হয়েছে; যাচাই না হওয়া পর্যন্ত Verified নয়।' };
}
