'use server';

import { redirect } from 'next/navigation';
import { eq, sql } from 'drizzle-orm';
import { compare } from 'bcryptjs';
import { z } from 'zod';
import { db } from '@/db';
import { adminUsers, adminLoginAttempts } from '@/db/schema';
import { createAdminSession } from '@/lib/auth';

const loginSchema = z.object({
  email: z.string().trim().email().max(254),
  password: z.string().min(1).max(200),
});

export async function loginAdmin(formData: FormData) {
  const parsed = loginSchema.safeParse({
    email: formData.get('email'),
    password: formData.get('password'),
  });
  if (!parsed.success) redirect('/admin/login?error=1');

  const email = parsed.data.email.toLowerCase();
  const [attempt] = await db.select().from(adminLoginAttempts)
    .where(eq(adminLoginAttempts.email, email)).limit(1);
  const now = new Date();

  if (attempt?.lockedUntil && attempt.lockedUntil > now) {
    redirect('/admin/login?error=1');
  }

  const [user] = await db.select().from(adminUsers)
    .where(eq(adminUsers.email, email)).limit(1);

  const valid = !!user && user.isActive && await compare(parsed.data.password, user.passwordHash);
  if (!valid) {
    // A new 15-minute window starts after the previous window expires.
    await db.insert(adminLoginAttempts).values({
      email, failedAttempts: 1, windowStartedAt: now, updatedAt: now,
    }).onConflictDoUpdate({
      target: adminLoginAttempts.email,
      set: {
        failedAttempts: sql`CASE
          WHEN ${adminLoginAttempts.windowStartedAt} < ${new Date(now.getTime() - 15 * 60 * 1000)}
          THEN 1 ELSE ${adminLoginAttempts.failedAttempts} + 1 END`,
        windowStartedAt: sql`CASE
          WHEN ${adminLoginAttempts.windowStartedAt} < ${new Date(now.getTime() - 15 * 60 * 1000)}
          THEN ${now} ELSE ${adminLoginAttempts.windowStartedAt} END`,
        lockedUntil: sql`CASE
          WHEN ${adminLoginAttempts.windowStartedAt} < ${new Date(now.getTime() - 15 * 60 * 1000)}
          THEN NULL
          WHEN ${adminLoginAttempts.failedAttempts} + 1 >= 5
          THEN ${new Date(now.getTime() + 15 * 60 * 1000)}
          ELSE NULL END`,
        updatedAt: now,
      },
    });
    redirect('/admin/login?error=1');
  }

  await db.delete(adminLoginAttempts).where(eq(adminLoginAttempts.email, email));
  await createAdminSession({ userId: user.id, email: user.email, role: user.role });
  redirect('/admin');
}
