import { redirect } from 'next/navigation';
import { getAdminSession } from '@/lib/auth';
import { loginAdmin } from './actions';

export default async function AdminLoginPage({ searchParams }: {
  searchParams: Promise<{ error?: string }>;
}) {
  if (await getAdminSession()) redirect('/admin');
  const params = await searchParams;
  return <main className="mx-auto flex min-h-screen max-w-md items-center px-5 py-12">
    <div className="w-full rounded-2xl border bg-white p-7 shadow-sm">
      <a href="/" className="text-sm text-emerald-800">← ভূমি জ্ঞান</a>
      <h1 className="mt-5 text-2xl font-bold">Admin Login</h1>
      <p className="mt-2 text-sm text-slate-600">শুধু অনুমোদিত প্রশাসক প্রবেশ করতে পারবেন।</p>
      {params.error && <p role="alert" className="mt-4 rounded-lg bg-red-50 p-3 text-sm text-red-700">ইমেইল অথবা পাসওয়ার্ড সঠিক নয়।</p>}
      <form action={loginAdmin} className="mt-6 grid gap-4">
        <label className="grid gap-1 text-sm font-medium">ইমেইল
          <input name="email" type="email" autoComplete="username" required className="rounded-lg border px-3 py-2 font-normal"/>
        </label>
        <label className="grid gap-1 text-sm font-medium">পাসওয়ার্ড
          <input name="password" type="password" autoComplete="current-password" required className="rounded-lg border px-3 py-2 font-normal"/>
        </label>
        <button className="rounded-xl bg-emerald-800 px-4 py-3 font-semibold text-white">প্রবেশ করুন</button>
      </form>
    </div>
  </main>;
}
