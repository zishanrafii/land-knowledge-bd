import { desc } from 'drizzle-orm';
import { db } from '@/db';
import { legalDocuments } from '@/db/schema';
import { requireAdmin } from '@/lib/auth';
import { redirect } from 'next/navigation';
import { updateVerification } from './actions';

const labels: Record<string,string> = {
  PENDING:'যাচাই বাকি',
  PARTIALLY_VERIFIED:'আংশিক যাচাইকৃত',
  VERIFIED:'যাচাইকৃত',
  INCORRECT_REPLACED:'ভুল / প্রতিস্থাপিত',
  DUPLICATE:'ডুপ্লিকেট',
};

export default async function ReviewQueue() {
  const admin = await requireAdmin(['SUPER_ADMIN','EDITOR','REVIEWER']);
  if (!admin) redirect('/admin/login');
  const docs = await db.select().from(legalDocuments).orderBy(desc(legalDocuments.createdAt)).limit(100);
  const canFinalize = admin.role === 'SUPER_ADMIN';

  return <main className="mx-auto min-h-screen max-w-5xl px-5 py-10">
    <div className="flex items-center justify-between"><a href="/admin" className="text-sm text-emerald-800">← Admin</a><span className="text-xs text-slate-500">{admin.role}</span></div>
    <h1 className="mt-5 text-3xl font-bold">আইনি নথি যাচাই</h1>
    <p className="mt-2 text-sm text-slate-600">প্রতিটি সিদ্ধান্তে যাচাইয়ের প্রমাণ/মন্তব্য লিখতে হবে। Verified, Incorrect/Replaced ও Duplicate সিদ্ধান্ত শুধু Super Admin দিতে পারবেন।</p>
    {docs.length === 0 ? <p className="mt-8 rounded-xl border bg-white p-5 text-sm text-slate-600">এখনো কোনো নথি নেই।</p> :
      <div className="mt-8 space-y-5">{docs.map(doc=><section key={doc.id} className="rounded-2xl border bg-white p-5">
        <div className="flex flex-wrap items-center gap-2"><span className="rounded-full bg-slate-100 px-2 py-1 text-xs">{doc.documentType}</span><span className="rounded-full bg-amber-50 px-2 py-1 text-xs text-amber-900">{labels[doc.status]}</span></div>
        <h2 className="mt-2 font-bold">{doc.titleBn}</h2>
        {doc.titleEn && <p className="text-sm text-slate-500">{doc.titleEn}</p>}
        <form action={updateVerification} className="mt-4 grid gap-3 border-t pt-4">
          <input type="hidden" name="documentId" value={doc.id}/>
          <label className="grid gap-1 text-sm font-medium">নতুন যাচাইয়ের অবস্থা
            <select name="status" defaultValue={doc.status} className="rounded-lg border px-3 py-2 font-normal">
              <option value="PENDING">যাচাই বাকি</option>
              <option value="PARTIALLY_VERIFIED">আংশিক যাচাইকৃত</option>
              {canFinalize && <><option value="VERIFIED">যাচাইকৃত</option><option value="INCORRECT_REPLACED">ভুল / প্রতিস্থাপিত</option><option value="DUPLICATE">ডুপ্লিকেট</option></>}
            </select>
          </label>
          <label className="grid gap-1 text-sm font-medium">যাচাই মন্তব্য / প্রমাণের বিবরণ
            <textarea name="notes" required minLength={8} maxLength={3000} rows={3} placeholder="কোন সরকারি উৎস, গেজেট, PDF বা ধারা পরীক্ষা করা হয়েছে তা লিখুন..." className="rounded-lg border px-3 py-2 font-normal"/>
          </label>
          <button className="justify-self-start rounded-xl bg-emerald-800 px-4 py-2.5 text-sm font-semibold text-white">সিদ্ধান্ত সংরক্ষণ</button>
        </form>
      </section>)}</div>
    }
  </main>;
}
