'use server';

import { revalidatePath } from 'next/cache';
import { eq } from 'drizzle-orm';
import { z } from 'zod';
import { db } from '@/db';
import { legalDocuments, verificationRecords } from '@/db/schema';
import { requireAdmin } from '@/lib/auth';

const reviewInput = z.object({
  documentId: z.string().uuid(),
  status: z.enum(['PENDING','PARTIALLY_VERIFIED','VERIFIED','INCORRECT_REPLACED','DUPLICATE']),
  notes: z.string().trim().min(8).max(3000),
});

export async function updateVerification(formData: FormData) {
  const admin = await requireAdmin(['SUPER_ADMIN','EDITOR','REVIEWER']);
  if (!admin) return { ok: false as const, message: 'অনুমতি নেই।' };

  const parsed = reviewInput.safeParse({
    documentId: formData.get('documentId'),
    status: formData.get('status'),
    notes: formData.get('notes'),
  });
  if (!parsed.success) return { ok: false as const, message: 'নথি, অবস্থা বা যাচাই মন্তব্য সঠিক নয়।' };

  const { documentId, status, notes } = parsed.data;

  // Only a Super Admin may publish a document as verified or mark it replaced/duplicate.
  if (['VERIFIED','INCORRECT_REPLACED','DUPLICATE'].includes(status) && admin.role !== 'SUPER_ADMIN') {
    return { ok: false as const, message: 'এই চূড়ান্ত সিদ্ধান্তের জন্য Super Admin অনুমতি প্রয়োজন।' };
  }

  const finalizedStatuses = ['VERIFIED','INCORRECT_REPLACED','DUPLICATE'];
  const [existing] = await db.select({ status: legalDocuments.status }).from(legalDocuments)
    .where(eq(legalDocuments.id, documentId)).limit(1);
  if (!existing) return { ok: false as const, message: 'নথিটি পাওয়া যায়নি।' };
  if (finalizedStatuses.includes(existing.status) && admin.role !== 'SUPER_ADMIN') {
    return { ok: false as const, message: 'চূড়ান্ত নথির অবস্থা পরিবর্তনে Super Admin প্রয়োজন।' };
  }

  const [updated] = await db.update(legalDocuments)
    .set({ status, updatedAt: new Date() })
    .where(eq(legalDocuments.id, documentId))
    .returning({ id: legalDocuments.id });

  if (!updated) return { ok: false as const, message: 'নথিটি পাওয়া যায়নি।' };

  await db.insert(verificationRecords).values({
    entityType: 'LEGAL_DOCUMENT',
    entityId: documentId,
    status,
    checkedBy: admin.email,
    notes,
  });

  revalidatePath('/admin/review');
  revalidatePath('/laws');
  return { ok: true as const, message: 'যাচাইয়ের সিদ্ধান্ত সংরক্ষিত হয়েছে।' };
}
