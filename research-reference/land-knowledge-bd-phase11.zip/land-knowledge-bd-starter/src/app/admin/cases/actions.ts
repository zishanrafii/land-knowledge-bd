'use server';

import { revalidatePath } from 'next/cache';
import { eq } from 'drizzle-orm';
import { z } from 'zod';
import { db } from '@/db';
import { courtCases, caseSources, caseAttachments, caseResearchNotes, verificationRecords } from '@/db/schema';
import { requireAdmin } from '@/lib/auth';
import { httpsUrl } from '@/lib/validation';

const optional = (value: FormDataEntryValue | null) =>
  typeof value === 'string' && value.trim() !== '' ? value.trim() : undefined;

const caseInput = z.object({
  slug: z.string().trim().min(2).max(200).regex(/^[a-z0-9-]+$/),
  caseTitle: z.string().trim().min(3).max(1000),
  caseNumber: z.string().trim().max(180).optional(),
  court: z.string().trim().min(2).max(180),
  courtDivision: z.string().trim().max(80).optional(),
  bench: z.string().trim().max(1000).optional(),
  caseType: z.string().trim().max(120).optional(),
  judgmentDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
  decisionType: z.string().trim().max(80).optional(),
  decisionStatus: z.string().trim().max(80).optional(),
  summaryBn: z.string().trim().max(12000).optional(),
  officialUrl: httpsUrl.optional(),
  sourceAuthority: z.string().trim().max(220).optional(),
  attachmentTitle: z.string().trim().max(300).optional(),
  attachmentUrl: httpsUrl.optional(),
  researchNote: z.string().trim().max(5000).optional(),
});

export async function createCourtCase(formData: FormData) {
  const admin = await requireAdmin(['SUPER_ADMIN', 'EDITOR']);
  if (!admin) return { ok: false as const, message: 'অনুমতি নেই।' };

  const parsed = caseInput.safeParse({
    slug: formData.get('slug'), caseTitle: formData.get('caseTitle'),
    caseNumber: optional(formData.get('caseNumber')), court: formData.get('court'),
    courtDivision: optional(formData.get('courtDivision')), bench: optional(formData.get('bench')),
    caseType: optional(formData.get('caseType')), judgmentDate: optional(formData.get('judgmentDate')),
    decisionType: optional(formData.get('decisionType')), decisionStatus: optional(formData.get('decisionStatus')),
    summaryBn: optional(formData.get('summaryBn')), officialUrl: optional(formData.get('officialUrl')),
    sourceAuthority: optional(formData.get('sourceAuthority')), attachmentTitle: optional(formData.get('attachmentTitle')),
    attachmentUrl: optional(formData.get('attachmentUrl')), researchNote: optional(formData.get('researchNote')),
  });
  if (!parsed.success) return { ok: false as const, message: 'তথ্য সঠিক নয়; শিরোনাম, slug, আদালত ও URL পরীক্ষা করুন।' };

  const d = parsed.data;
  const [created] = await db.insert(courtCases).values({
    slug: d.slug, caseTitle: d.caseTitle, caseNumber: d.caseNumber, court: d.court,
    courtDivision: d.courtDivision, bench: d.bench, caseType: d.caseType,
    judgmentDate: d.judgmentDate, decisionType: d.decisionType, decisionStatus: d.decisionStatus,
    summaryBn: d.summaryBn, officialUrl: d.officialUrl, status: 'PENDING',
  }).returning({ id: courtCases.id });

  if (d.officialUrl) await db.insert(caseSources).values({
    caseId: created.id, authority: d.sourceAuthority || 'উৎস যাচাই বাকি',
    sourceUrl: d.officialUrl, sourceKind: 'OFFICIAL_OR_PRIMARY_SOURCE', isPrimary: true,
  });
  if (d.attachmentUrl) await db.insert(caseAttachments).values({
    caseId: created.id, title: d.attachmentTitle || 'রায়ের মূল নথি',
    fileUrl: d.attachmentUrl, mimeType: 'application/pdf',
    sourceAuthority: d.sourceAuthority || 'উৎস যাচাই বাকি',
  });
  if (d.researchNote) await db.insert(caseResearchNotes).values({
    caseId: created.id, note: d.researchNote, createdBy: admin.email,
    noteType: 'RESEARCH', visibility: 'INTERNAL',
  });
  await db.insert(verificationRecords).values({
    entityType: 'COURT_CASE', entityId: created.id, status: 'PENDING',
    checkedBy: admin.email, notes: 'নতুন মামলা/রায় Admin intake থেকে যোগ হয়েছে; মূল রায় যাচাই বাকি।',
  });
  revalidatePath('/admin/cases');
  revalidatePath('/admin/cases/review');
  revalidatePath('/cases');
  return { ok: true as const, message: 'মামলার তথ্য Pending অবস্থায় সংরক্ষিত হয়েছে।' };
}

export async function updateCourtCase(formData: FormData) {
  const admin = await requireAdmin(['SUPER_ADMIN', 'EDITOR']);
  if (!admin) return { ok: false as const, message: 'অনুমতি নেই।' };
  const id = formData.get('caseId');
  if (typeof id !== 'string' || !z.string().uuid().safeParse(id).success) return { ok: false as const, message: 'মামলার ID সঠিক নয়।' };
  const parsed = caseInput.pick({
    slug: true, caseTitle: true, caseNumber: true, court: true, courtDivision: true,
    bench: true, caseType: true, judgmentDate: true, decisionType: true, decisionStatus: true,
    summaryBn: true, officialUrl: true,
  }).safeParse({
    slug: formData.get('slug'), caseTitle: formData.get('caseTitle'),
    caseNumber: optional(formData.get('caseNumber')), court: formData.get('court'),
    courtDivision: optional(formData.get('courtDivision')), bench: optional(formData.get('bench')),
    caseType: optional(formData.get('caseType')), judgmentDate: optional(formData.get('judgmentDate')),
    decisionType: optional(formData.get('decisionType')), decisionStatus: optional(formData.get('decisionStatus')),
    summaryBn: optional(formData.get('summaryBn')), officialUrl: optional(formData.get('officialUrl')),
  });
  if (!parsed.success) return { ok: false as const, message: 'সম্পাদনার তথ্য সঠিক নয়।' };
  const [updated] = await db.update(courtCases).set({
    ...parsed.data, status: 'PENDING', updatedAt: new Date(),
  }).where(eq(courtCases.id, id)).returning({ id: courtCases.id });
  if (!updated) return { ok: false as const, message: 'মামলাটি পাওয়া যায়নি।' };
  await db.insert(verificationRecords).values({
    entityType: 'COURT_CASE', entityId: id, status: 'PENDING',
    checkedBy: admin.email, notes: 'মামলার metadata সম্পাদনা করা হয়েছে; সম্পাদিত তথ্য পুনরায় যাচাই করতে হবে।',
  });
  revalidatePath('/admin/cases');
  revalidatePath('/admin/cases/review');
  revalidatePath('/cases');
  return { ok: true as const, message: 'মামলার তথ্য আপডেট হয়েছে এবং পুনরায় যাচাইয়ের জন্য Pending করা হয়েছে।' };
}

export async function addCaseResearchNote(formData: FormData) {
  const admin = await requireAdmin(['SUPER_ADMIN', 'EDITOR', 'REVIEWER']);
  if (!admin) return { ok: false as const, message: 'অনুমতি নেই।' };
  const id = formData.get('caseId');
  const note = formData.get('note');
  if (typeof id !== 'string' || !z.string().uuid().safeParse(id).success ||
      typeof note !== 'string' || note.trim().length < 5 || note.length > 5000) {
    return { ok: false as const, message: 'মন্তব্যের তথ্য সঠিক নয়।' };
  }
  const [found] = await db.select({ id: courtCases.id }).from(courtCases).where(eq(courtCases.id, id)).limit(1);
  if (!found) return { ok: false as const, message: 'মামলাটি পাওয়া যায়নি।' };
  await db.insert(caseResearchNotes).values({
    caseId: id, note: note.trim(), createdBy: admin.email,
    noteType: 'RESEARCH', visibility: 'INTERNAL',
  });
  revalidatePath('/admin/cases');
  return { ok: true as const, message: 'Internal research note সংরক্ষিত হয়েছে।' };
}
