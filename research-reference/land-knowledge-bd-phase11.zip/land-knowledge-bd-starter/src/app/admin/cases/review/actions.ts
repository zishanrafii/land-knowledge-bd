'use server';

import { revalidatePath } from 'next/cache';
import { eq } from 'drizzle-orm';
import { z } from 'zod';
import { db } from '@/db';
import { courtCases, verificationRecords } from '@/db/schema';
import { requireAdmin } from '@/lib/auth';

const schema = z.object({
  caseId: z.string().uuid(),
  status: z.enum(['PENDING','PARTIALLY_VERIFIED','VERIFIED','INCORRECT_REPLACED','DUPLICATE']),
  notes: z.string().trim().min(8).max(3000),
});

export async function reviewCourtCase(formData: FormData) {
  const admin = await requireAdmin(['SUPER_ADMIN','EDITOR','REVIEWER']);
  if (!admin) return { ok: false as const, message: 'অনুমতি নেই।' };
  const parsed = schema.safeParse({
    caseId: formData.get('caseId'), status: formData.get('status'), notes: formData.get('notes'),
  });
  if (!parsed.success) return { ok: false as const, message: 'তথ্য বা যাচাই মন্তব্য সঠিক নয়।' };
  const { caseId, status, notes } = parsed.data;
  const finalizedStatuses = ['VERIFIED','INCORRECT_REPLACED','DUPLICATE'];
  if (['VERIFIED','INCORRECT_REPLACED','DUPLICATE'].includes(status) && admin.role !== 'SUPER_ADMIN') {
    return { ok: false as const, message: 'চূড়ান্ত যাচাইয়ের জন্য Super Admin প্রয়োজন।' };
  }
  const [current] = await db.select({ id: courtCases.id, status: courtCases.status })
    .from(courtCases).where(eq(courtCases.id, caseId)).limit(1);
  if (!current) return { ok: false as const, message: 'মামলাটি পাওয়া যায়নি।' };
  if (finalizedStatuses.includes(current.status) && admin.role !== 'SUPER_ADMIN') {
    return { ok: false as const, message: 'চূড়ান্ত মামলার অবস্থা পরিবর্তনে Super Admin প্রয়োজন।' };
  }
  await db.update(courtCases).set({ status, updatedAt: new Date() }).where(eq(courtCases.id, caseId));
  await db.insert(verificationRecords).values({
    entityType: 'COURT_CASE', entityId: caseId, status, checkedBy: admin.email, notes,
  });
  revalidatePath('/admin/cases');
  revalidatePath('/admin/cases/review');
  revalidatePath('/cases');
  return { ok: true as const, message: 'যাচাইয়ের সিদ্ধান্ত সংরক্ষিত হয়েছে।' };
}
