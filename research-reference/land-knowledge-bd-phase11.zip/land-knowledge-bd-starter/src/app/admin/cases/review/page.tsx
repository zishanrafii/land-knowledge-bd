import { desc } from 'drizzle-orm';
import { redirect } from 'next/navigation';
import { db } from '@/db';
import { courtCases } from '@/db/schema';
import { requireAdmin } from '@/lib/auth';
import { reviewCourtCase } from './actions';

const statusBn: Record<string,string> = {
  PENDING: 'যাচাই বাকি', PARTIALLY_VERIFIED: 'আংশিক যাচাইকৃত',
  VERIFIED: 'যাচাইকৃত', INCORRECT_REPLACED: 'ভুল / প্রতিস্থাপিত', DUPLICATE: 'ডুপ্লিকেট',
};

export default async function CourtCaseReviewPage() {
  const admin = await requireAdmin(['SUPER_ADMIN','EDITOR','REVIEWER']);
  if (!admin) redirect('/admin/login');
  const rows = await db.select().from(courtCases).orderBy(desc(courtCases.createdAt)).limit(150);
  const canFinalize = admin.role === 'SUPER_ADMIN';
  return <main className="mx-auto min-h-screen max-w-5xl px-5 py-10">
    <a href="/admin/cases" className="text-sm text-emerald-800">← মামলা ব্যবস্থাপনা</a>
    <h1 className="mt-5 text-3xl font-bold">মামলার যাচাই Queue</h1>
    <p className="mt-2 text-sm text-slate-600">রায়ের মূল সরকারি কপি ও মামলা নম্বর যাচাই ছাড়া Verified করবেন না। চূড়ান্ত status শুধু Super Admin দিতে পারবেন।</p>
    <div className="mt-7 space-y-5">{rows.map(item=><section key={item.id} className="rounded-2xl border bg-white p-5">
      <span className="rounded-full bg-slate-100 px-2 py-1 text-xs">{statusBn[item.status]}</span>
      <h2 className="mt-2 font-bold">{item.caseTitle}</h2>
      <p className="text-sm text-slate-500">{item.court} · {item.caseNumber || 'মামলা নম্বর অনুল্লিখিত'} · {item.judgmentDate || 'তারিখ অনুল্লিখিত'}</p>
      {item.officialUrl && <a href={item.officialUrl} target="_blank" rel="noreferrer" className="mt-2 block break-all text-sm text-emerald-800 underline">মূল উৎস খুলুন</a>}
      <form action={reviewCourtCase} className="mt-4 grid gap-3 border-t pt-4">
        <input type="hidden" name="caseId" value={item.id}/>
        <label className="grid gap-1 text-sm font-medium">যাচাইয়ের অবস্থা
          <select name="status" defaultValue={item.status} className="rounded-lg border px-3 py-2 font-normal">
            <option value="PENDING">যাচাই বাকি</option><option value="PARTIALLY_VERIFIED">আংশিক যাচাইকৃত</option>
            {canFinalize && <><option value="VERIFIED">যাচাইকৃত</option><option value="INCORRECT_REPLACED">ভুল / প্রতিস্থাপিত</option><option value="DUPLICATE">ডুপ্লিকেট</option></>}
          </select>
        </label>
        <label className="grid gap-1 text-sm font-medium">যাচাইয়ের প্রমাণ / মন্তব্য<textarea name="notes" required minLength={8} maxLength={3000} rows={3} className="rounded-lg border px-3 py-2 font-normal" placeholder="সরকারি PDF, মামলার নম্বর, রায়ের তারিখ ও কোন অংশ পরীক্ষা করেছেন লিখুন..."/></label>
        <button className="justify-self-start rounded-xl bg-emerald-800 px-4 py-2.5 text-sm font-semibold text-white">যাচাই সিদ্ধান্ত সংরক্ষণ</button>
      </form>
    </section>)}</div>
  </main>;
}
