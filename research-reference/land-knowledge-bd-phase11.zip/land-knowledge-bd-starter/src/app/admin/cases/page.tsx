import { desc, eq, sql } from 'drizzle-orm';
import { redirect } from 'next/navigation';
import { db } from '@/db';
import { courtCases, caseSources, caseAttachments, caseResearchNotes } from '@/db/schema';
import { requireAdmin } from '@/lib/auth';
import { createCourtCase, updateCourtCase, addCaseResearchNote } from './actions';

export default async function AdminCasesPage() {
  const admin = await requireAdmin(['SUPER_ADMIN','EDITOR','REVIEWER']);
  if (!admin) redirect('/admin/login');
  const rows = await db.select().from(courtCases).orderBy(desc(courtCases.createdAt)).limit(100);
  const sourceCounts = await db.select({ caseId: caseSources.caseId, count: sql<number>`count(*)::int` })
    .from(caseSources).groupBy(caseSources.caseId);
  const attachmentCounts = await db.select({ caseId: caseAttachments.caseId, count: sql<number>`count(*)::int` })
    .from(caseAttachments).groupBy(caseAttachments.caseId);
  const noteCounts = await db.select({ caseId: caseResearchNotes.caseId, count: sql<number>`count(*)::int` })
    .from(caseResearchNotes).groupBy(caseResearchNotes.caseId);
  const count = (items: {caseId:string; count:number}[], id:string) => items.find(x => x.caseId === id)?.count ?? 0;

  return <main className="mx-auto min-h-screen max-w-6xl px-5 py-10">
    <div className="flex flex-wrap items-center justify-between gap-3"><a href="/admin" className="text-sm text-emerald-800">← Admin Dashboard</a><span className="text-xs text-slate-500">{admin.role}</span></div>
    <h1 className="mt-5 text-3xl font-bold">আদালতের রায় ও মামলা ব্যবস্থাপনা</h1>
    <p className="mt-2 text-sm text-slate-600">প্রতিটি মামলার ক্ষেত্রে মূল রায়ের সরকারি উৎস, মামলা নম্বর, তারিখ এবং সিদ্ধান্তের ধরন যাচাই করুন। সংযুক্তি এখানে URL metadata; সরাসরি ফাইল আপলোড নয়।</p>

    {admin.role !== 'REVIEWER' && <form action={createCourtCase} className="mt-7 grid gap-4 rounded-2xl border bg-white p-6">
      <h2 className="text-xl font-bold">নতুন মামলা / রায় যোগ করুন</h2>
      <div className="grid gap-4 sm:grid-cols-2">
        <label className="grid gap-1 text-sm font-medium">মামলার শিরোনাম<input name="caseTitle" required className="rounded-lg border px-3 py-2 font-normal"/></label>
        <label className="grid gap-1 text-sm font-medium">Slug<input name="slug" required pattern="[a-z0-9-]+" className="rounded-lg border px-3 py-2 font-normal"/></label>
        <label className="grid gap-1 text-sm font-medium">মামলা নম্বর<input name="caseNumber" className="rounded-lg border px-3 py-2 font-normal"/></label>
        <label className="grid gap-1 text-sm font-medium">আদালত<input name="court" required defaultValue="Supreme Court of Bangladesh" className="rounded-lg border px-3 py-2 font-normal"/></label>
        <label className="grid gap-1 text-sm font-medium">বিভাগ<select name="courtDivision" className="rounded-lg border px-3 py-2 font-normal"><option value="">উল্লেখ নেই</option><option>High Court Division</option><option>Appellate Division</option></select></label>
        <label className="grid gap-1 text-sm font-medium">বেঞ্চ<input name="bench" className="rounded-lg border px-3 py-2 font-normal"/></label>
        <label className="grid gap-1 text-sm font-medium">মামলার ধরন<input name="caseType" className="rounded-lg border px-3 py-2 font-normal"/></label>
        <label className="grid gap-1 text-sm font-medium">রায়ের তারিখ<input name="judgmentDate" type="date" className="rounded-lg border px-3 py-2 font-normal"/></label>
        <label className="grid gap-1 text-sm font-medium">সিদ্ধান্তের ধরন<input name="decisionType" className="rounded-lg border px-3 py-2 font-normal"/></label>
        <label className="grid gap-1 text-sm font-medium">মামলার বর্তমান অবস্থা<input name="decisionStatus" className="rounded-lg border px-3 py-2 font-normal"/></label>
      </div>
      <label className="grid gap-1 text-sm font-medium">বাংলা সারসংক্ষেপ<textarea name="summaryBn" rows={3} className="rounded-lg border px-3 py-2 font-normal"/></label>
      <div className="grid gap-4 sm:grid-cols-2">
        <label className="grid gap-1 text-sm font-medium">সরকারি রায় / উৎস URL<input name="officialUrl" type="url" className="rounded-lg border px-3 py-2 font-normal"/></label>
        <label className="grid gap-1 text-sm font-medium">উৎস কর্তৃপক্ষ<input name="sourceAuthority" className="rounded-lg border px-3 py-2 font-normal"/></label>
        <label className="grid gap-1 text-sm font-medium">PDF শিরোনাম<input name="attachmentTitle" className="rounded-lg border px-3 py-2 font-normal"/></label>
        <label className="grid gap-1 text-sm font-medium">PDF URL<input name="attachmentUrl" type="url" className="rounded-lg border px-3 py-2 font-normal"/></label>
      </div>
      <label className="grid gap-1 text-sm font-medium">Internal research note (ঐচ্ছিক)<textarea name="researchNote" rows={2} className="rounded-lg border px-3 py-2 font-normal"/></label>
      <button className="justify-self-start rounded-xl bg-emerald-800 px-5 py-3 font-semibold text-white">Pending হিসেবে সংরক্ষণ</button>
    </form>}

    <section className="mt-10"><div className="flex flex-wrap items-center justify-between gap-2"><h2 className="text-xl font-bold">সংরক্ষিত মামলা ({rows.length})</h2><a href="/admin/cases/review" className="text-sm text-emerald-800 underline">যাচাই Queue</a></div>
      <div className="mt-4 space-y-5">{rows.map(item=><article key={item.id} className="rounded-2xl border bg-white p-5">
        <div className="flex flex-wrap items-center gap-2"><span className="rounded-full bg-slate-100 px-2 py-1 text-xs">{item.status}</span><span className="text-xs text-slate-500">{item.court} · {item.caseNumber || 'মামলা নম্বর অনুল্লিখিত'}</span></div>
        <h3 className="mt-2 font-bold">{item.caseTitle}</h3>
        <p className="mt-1 text-xs text-slate-500">Sources: {count(sourceCounts,item.id)} · Attachments: {count(attachmentCounts,item.id)} · Internal notes: {count(noteCounts,item.id)}</p>
        {admin.role !== 'REVIEWER' && <details className="mt-4"><summary className="cursor-pointer text-sm font-semibold text-emerald-800">তথ্য সম্পাদনা</summary>
          <form action={updateCourtCase} className="mt-3 grid gap-3 border-t pt-3">
            <input type="hidden" name="caseId" value={item.id}/>
            <div className="grid gap-3 sm:grid-cols-2">
              <label className="grid gap-1 text-sm">শিরোনাম<input name="caseTitle" required defaultValue={item.caseTitle} className="rounded-lg border px-3 py-2"/></label>
              <label className="grid gap-1 text-sm">Slug<input name="slug" required defaultValue={item.slug} className="rounded-lg border px-3 py-2"/></label>
              <label className="grid gap-1 text-sm">মামলা নম্বর<input name="caseNumber" defaultValue={item.caseNumber || ''} className="rounded-lg border px-3 py-2"/></label>
              <label className="grid gap-1 text-sm">আদালত<input name="court" required defaultValue={item.court} className="rounded-lg border px-3 py-2"/></label>
              <label className="grid gap-1 text-sm">বিভাগ<input name="courtDivision" defaultValue={item.courtDivision || ''} className="rounded-lg border px-3 py-2"/></label>
              <label className="grid gap-1 text-sm">রায়ের তারিখ<input name="judgmentDate" type="date" defaultValue={item.judgmentDate || ''} className="rounded-lg border px-3 py-2"/></label>
            </div>
            <label className="grid gap-1 text-sm">বাংলা সারসংক্ষেপ<textarea name="summaryBn" defaultValue={item.summaryBn || ''} rows={2} className="rounded-lg border px-3 py-2"/></label>
            <label className="grid gap-1 text-sm">সরকারি URL<input name="officialUrl" type="url" defaultValue={item.officialUrl || ''} className="rounded-lg border px-3 py-2"/></label>
            <button className="justify-self-start rounded-lg border px-4 py-2 text-sm font-semibold">তথ্য আপডেট</button>
          </form>
        </details>}
        <form action={addCaseResearchNote} className="mt-4 grid gap-2 border-t pt-3">
          <input type="hidden" name="caseId" value={item.id}/>
          <label className="text-sm font-semibold">Internal research note</label>
          <textarea name="note" required minLength={5} rows={2} placeholder="কোন সরকারি রায়/PDF/ধারা পরীক্ষা করতে হবে..." className="rounded-lg border px-3 py-2 text-sm"/>
          <button className="justify-self-start rounded-lg border px-4 py-2 text-sm">নোট সংরক্ষণ</button>
        </form>
      </article>)}</div>
    </section>
  </main>;
}
