import { desc, sql } from 'drizzle-orm';
import { redirect } from 'next/navigation';
import { db } from '@/db';
import { legalDocuments, courtCases, verificationRecords } from '@/db/schema';
import { requireAdmin } from '@/lib/auth';
import { createLegalDocument } from './actions';
import { logoutAdmin } from './logout/actions';

export default async function AdminPage() {
  const admin = await requireAdmin(['SUPER_ADMIN','EDITOR','REVIEWER']);
  if (!admin) redirect('/admin/login');

  const [docStats] = await db.select({
    total: sql<number>`count(*)::int`,
    pending: sql<number>`count(*) filter (where ${legalDocuments.status} = 'PENDING')::int`,
    verified: sql<number>`count(*) filter (where ${legalDocuments.status} = 'VERIFIED')::int`,
  }).from(legalDocuments);
  const [caseStats] = await db.select({
    total: sql<number>`count(*)::int`,
    pending: sql<number>`count(*) filter (where ${courtCases.status} = 'PENDING')::int`,
  }).from(courtCases);
  const recentDocs = await db.select({
    id: legalDocuments.id, titleBn: legalDocuments.titleBn,
    type: legalDocuments.documentType, status: legalDocuments.status,
  }).from(legalDocuments).orderBy(desc(legalDocuments.createdAt)).limit(5);

  return <main className="mx-auto min-h-screen max-w-6xl px-5 py-10">
    <div className="flex flex-wrap items-center justify-between gap-3">
      <a href="/" className="text-sm text-emerald-800">← হোম</a>
      <div className="flex items-center gap-3"><span className="text-xs text-slate-500">{admin.email} · {admin.role}</span>
        <form action={logoutAdmin}><button className="rounded-lg border px-3 py-2 text-sm">Logout</button></form>
      </div>
    </div>
    <div className="mt-5 flex flex-wrap items-center justify-between gap-3">
      <div><h1 className="text-3xl font-bold">আইনভান্ডার প্রশাসন</h1><p className="mt-1 text-sm text-slate-600">নথি, উৎস, আদালতের রায় এবং যাচাই কার্যক্রম</p></div>
      <div className="flex flex-wrap gap-2">
        <a href="/admin/review" className="rounded-lg bg-emerald-800 px-4 py-2 text-sm font-semibold text-white">আইন যাচাই Queue</a>
        <a href="/admin/sources" className="rounded-lg border px-4 py-2 text-sm font-semibold">উৎস ও PDF</a>
        <a href="/admin/cases" className="rounded-lg border px-4 py-2 text-sm font-semibold">মামলা ব্যবস্থাপনা</a>
      </div>
    </div>
    <div className="mt-7 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
      <div className="rounded-xl border bg-white p-4"><p className="text-sm text-slate-500">মোট আইন / নথি</p><p className="mt-1 text-2xl font-bold">{docStats.total}</p></div>
      <div className="rounded-xl border bg-white p-4"><p className="text-sm text-slate-500">আইন Pending</p><p className="mt-1 text-2xl font-bold">{docStats.pending}</p></div>
      <div className="rounded-xl border bg-white p-4"><p className="text-sm text-slate-500">যাচাইকৃত আইন</p><p className="mt-1 text-2xl font-bold">{docStats.verified}</p></div>
      <div className="rounded-xl border bg-white p-4"><p className="text-sm text-slate-500">মামলা / রায়</p><p className="mt-1 text-2xl font-bold">{caseStats.total} <span className="text-sm font-normal text-slate-500">({caseStats.pending} Pending)</span></p></div>
    </div>
    {admin.role !== 'REVIEWER' && <form action={createLegalDocument} className="mt-8 grid gap-4 rounded-2xl border bg-white p-6">
      <h2 className="text-xl font-bold">নতুন আইন / নথি যোগ করুন</h2>
      <p className="text-sm text-slate-600">নতুন নথি সবসময় Pending থাকবে; সরকারি মূল উৎস যাচাইয়ের পর Super Admin চূড়ান্ত status দিতে পারবেন।</p>
      <label className="grid gap-1 text-sm font-medium">বাংলা শিরোনাম<input name="titleBn" required minLength={2} className="rounded-lg border px-3 py-2 font-normal"/></label>
      <label className="grid gap-1 text-sm font-medium">English title<input name="titleEn" className="rounded-lg border px-3 py-2 font-normal"/></label>
      <label className="grid gap-1 text-sm font-medium">Slug<input name="slug" required pattern="[a-z0-9-]+" className="rounded-lg border px-3 py-2 font-normal"/></label>
      <label className="grid gap-1 text-sm font-medium">নথির ধরন<select name="documentType" required className="rounded-lg border px-3 py-2 font-normal">{['ACT','ORDINANCE','RULE','REGULATION','POLICY','GAZETTE','CIRCULAR','NOTIFICATION','MANUAL','GUIDELINE','COURT_JUDGMENT','OTHER'].map(v=><option key={v}>{v}</option>)}</select></label>
      <label className="grid gap-1 text-sm font-medium">আইন / নথি নম্বর<input name="documentNumber" className="rounded-lg border px-3 py-2 font-normal"/></label>
      <div className="grid gap-4 sm:grid-cols-2">
        <label className="grid gap-1 text-sm font-medium">প্রকাশের তারিখ<input name="publicationDate" type="date" className="rounded-lg border px-3 py-2 font-normal"/></label>
        <label className="grid gap-1 text-sm font-medium">কার্যকারিতার তারিখ<input name="commencementDate" type="date" className="rounded-lg border px-3 py-2 font-normal"/></label>
      </div>
      <label className="grid gap-1 text-sm font-medium">প্রাথমিক উৎসের URL<input name="sourceUrl" type="url" placeholder="https://..." className="rounded-lg border px-3 py-2 font-normal"/></label>
      <button className="justify-self-start rounded-xl bg-emerald-800 px-5 py-3 font-semibold text-white">Pending হিসেবে সংরক্ষণ</button>
    </form>}
    <section className="mt-10"><h2 className="text-xl font-bold">সাম্প্রতিক আইন / নথি</h2>
      <div className="mt-3 divide-y rounded-2xl border bg-white">{recentDocs.map(doc=><div key={doc.id} className="flex flex-wrap items-center justify-between gap-2 p-4"><div><p className="font-semibold">{doc.titleBn}</p><p className="text-xs text-slate-500">{doc.type}</p></div><span className="rounded-full bg-slate-100 px-2 py-1 text-xs">{doc.status}</span></div>)}</div>
    </section>
  </main>;
}
