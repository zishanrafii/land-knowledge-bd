import Link from 'next/link';
import { and, eq } from 'drizzle-orm';
import { notFound } from 'next/navigation';
import { db } from '@/db';
import { caseAttachments, caseLegalLinks, caseSources, courtCases, legalDocuments } from '@/db/schema';

export default async function CaseDetail({ params }: { params: Promise<{slug:string}> }) {
  const {slug}=await params;
  const [item]=await db.select().from(courtCases).where(and(eq(courtCases.slug,slug),eq(courtCases.status,'VERIFIED'))).limit(1);
  if(!item) notFound();
  const [sources, attachments, links] = await Promise.all([
    db.select().from(caseSources).where(eq(caseSources.caseId,item.id)),
    db.select().from(caseAttachments).where(eq(caseAttachments.caseId,item.id)),
    db.select({link:caseLegalLinks, document:legalDocuments}).from(caseLegalLinks).innerJoin(legalDocuments,eq(caseLegalLinks.documentId,legalDocuments.id)).where(eq(caseLegalLinks.caseId,item.id))
  ]);
  return <main className="mx-auto min-h-screen max-w-4xl px-5 py-12">
    <Link href="/cases" className="text-sm text-emerald-800">← রায় অনুসন্ধান</Link>
    <div className="mt-5 flex flex-wrap gap-2"><span className="rounded-full bg-slate-100 px-3 py-1 text-xs">{item.courtDivision || item.court}</span><span className="rounded-full bg-emerald-50 px-3 py-1 text-xs text-emerald-800">যাচাইকৃত</span><span className="rounded-full bg-amber-50 px-3 py-1 text-xs text-amber-900">{item.decisionType || 'সিদ্ধান্তের ধরন অনির্দিষ্ট'}</span></div>
    <h1 className="mt-4 text-3xl font-bold">{item.caseTitle}</h1>
    <dl className="mt-6 grid gap-3 rounded-2xl border bg-white p-5 sm:grid-cols-2">
      <div><dt className="text-xs text-slate-500">মামলা নম্বর</dt><dd>{item.caseNumber || 'উল্লেখ নেই'}</dd></div>
      <div><dt className="text-xs text-slate-500">রায়ের তারিখ</dt><dd>{item.judgmentDate || 'উল্লেখ নেই'}</dd></div>
      <div><dt className="text-xs text-slate-500">আদালত</dt><dd>{item.court}</dd></div>
      <div><dt className="text-xs text-slate-500">Bench</dt><dd>{item.bench || 'উৎসে উল্লেখ নেই'}</dd></div>
      <div><dt className="text-xs text-slate-500">মামলার ধরন</dt><dd>{item.caseType || 'উল্লেখ নেই'}</dd></div>
      <div><dt className="text-xs text-slate-500">সিদ্ধান্তের অবস্থা</dt><dd>{item.decisionStatus || 'স্বতন্ত্রভাবে যাচাই করা হয়নি'}</dd></div>
    </dl>
    {item.summaryBn && <section className="mt-8"><h2 className="text-xl font-bold">সারসংক্ষেপ</h2><p className="mt-2 whitespace-pre-wrap leading-7 text-slate-700">{item.summaryBn}</p></section>}
    {item.judgmentTextBn && <section className="mt-8"><h2 className="text-xl font-bold">রায়ের পাঠ</h2><p className="mt-3 whitespace-pre-wrap rounded-xl border bg-white p-5 leading-8 text-slate-700">{item.judgmentTextBn}</p></section>}
    <section className="mt-8"><h2 className="text-xl font-bold">সরকারি উৎস</h2>{sources.length ? <ul className="mt-3 space-y-2">{sources.map(s=><li key={s.id} className="rounded-xl border bg-white p-4"><p className="font-semibold">{s.authority}</p><p className="text-xs text-slate-500">{s.sourceKind}</p><a href={s.sourceUrl} target="_blank" rel="noreferrer" className="break-all text-sm text-emerald-800 underline">মূল উৎস খুলুন</a></li>)}</ul> : item.officialUrl ? <a href={item.officialUrl} target="_blank" rel="noreferrer" className="mt-3 inline-block text-emerald-800 underline">সরকারি উৎস খুলুন</a> : <p className="mt-2 text-sm text-slate-600">আলাদা উৎস লিংক যুক্ত হয়নি।</p>}</section>
    {attachments.length>0 && <section className="mt-8"><h2 className="text-xl font-bold">রায়ের PDF / সংযুক্তি</h2><ul className="mt-3 space-y-2">{attachments.map(a=><li key={a.id} className="rounded-xl border bg-white p-4"><a href={a.fileUrl} target="_blank" rel="noreferrer" className="text-emerald-800 underline">{a.title}</a>{a.sourceAuthority&&<p className="mt-1 text-xs text-slate-500">{a.sourceAuthority}</p>}</li>)}</ul></section>}
    {links.length>0 && <section className="mt-8"><h2 className="text-xl font-bold">সম্পর্কিত আইন ও ধারা</h2><ul className="mt-3 space-y-2">{links.map(({link,document})=><li key={link.id} className="rounded-xl border bg-white p-4"><Link href={`/laws/${document.slug}`} className="font-semibold text-emerald-800 underline">{document.titleBn}</Link>{link.sectionNumber&&<p className="mt-1 text-sm">ধারা {link.sectionNumber}</p>}{link.relationNoteBn&&<p className="mt-1 text-sm text-slate-600">{link.relationNoteBn}</p>}</li>)}</ul></section>}
    <p className="mt-10 rounded-xl bg-amber-50 p-4 text-sm leading-6 text-amber-900">রায়ের সারসংক্ষেপ মূল রায়ের বিকল্প নয়। উদ্ধৃতি, নজির বা মামলার কৌশলে ব্যবহারের আগে মূল স্বাক্ষরিত/প্রকাশিত রায় এবং পরবর্তী আপিল বা সংশোধিত সিদ্ধান্ত যাচাই করুন।</p>
  </main>;
}
