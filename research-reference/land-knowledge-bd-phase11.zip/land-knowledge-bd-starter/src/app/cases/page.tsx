import Link from 'next/link';
import { and, asc, eq, gte, ilike, lt, or } from 'drizzle-orm';
import { db } from '@/db';
import { courtCases } from '@/db/schema';

const divisions = ['Appellate Division','High Court Division'];
const decisionTypes = ['FINAL_JUDGMENT','INTERIM_ORDER','RULE','OTHER'];
const decisionLabels: Record<string,string> = { FINAL_JUDGMENT:'চূড়ান্ত রায়', INTERIM_ORDER:'অন্তর্বর্তী আদেশ', RULE:'Rule', OTHER:'অন্যান্য আদেশ' };

export default async function CasesPage({ searchParams }: { searchParams: Promise<{q?:string; court?:string; decision?:string; year?:string}> }) {
  const p = await searchParams;
  const q = (p.q || '').trim().slice(0,120);
  const court = divisions.includes(p.court || '') ? p.court! : '';
  const decision = decisionTypes.includes(p.decision || '') ? p.decision! : '';
  const year = /^\d{4}$/.test(p.year || '') ? p.year! : '';
  const filters = [eq(courtCases.status,'VERIFIED')];
  if (court) filters.push(eq(courtCases.courtDivision,court));
  if (decision) filters.push(eq(courtCases.decisionType,decision));
  if (q) filters.push(or(ilike(courtCases.caseTitle,`%${q}%`),ilike(courtCases.caseNumber,`%${q}%`),ilike(courtCases.summaryBn,`%${q}%`))!);
  if (year) { filters.push(gte(courtCases.judgmentDate,`${year}-01-01`)); filters.push(lt(courtCases.judgmentDate,`${Number(year)+1}-01-01`)); }
  let rows: Array<typeof courtCases.$inferSelect> = [];
  let dbReady = true;
  try { rows = await db.select().from(courtCases).where(and(...filters)).orderBy(asc(courtCases.judgmentDate)).limit(100); }
  catch { dbReady = false; }
  return <main className="mx-auto min-h-screen max-w-5xl px-5 py-12">
    <Link href="/" className="text-sm text-emerald-800">← হোম</Link>
    <h1 className="mt-5 text-3xl font-bold">আদালতের রায় ও আদেশ</h1>
    <p className="mt-2 leading-7 text-slate-600">বাংলাদেশ সুপ্রিম কোর্টের প্রকাশিত ভূমি-সম্পর্কিত সিদ্ধান্ত অনুসন্ধান করুন। যাচাই সম্পন্ন নথিই এখানে প্রকাশিত হয়।</p>
    <form className="mt-6 grid gap-3 rounded-2xl border bg-white p-4 sm:grid-cols-2">
      <input name="q" defaultValue={q} placeholder="মামলার নাম, নম্বর বা বিষয় লিখুন" className="rounded-lg border px-3 py-2 sm:col-span-2"/>
      <select name="court" defaultValue={court} className="rounded-lg border px-3 py-2"><option value="">সব বিভাগ</option>{divisions.map(v=><option key={v}>{v}</option>)}</select>
      <select name="decision" defaultValue={decision} className="rounded-lg border px-3 py-2"><option value="">সব সিদ্ধান্তের ধরন</option>{decisionTypes.map(v=><option key={v} value={v}>{decisionLabels[v]}</option>)}</select>
      <input name="year" defaultValue={year} inputMode="numeric" placeholder="রায়ের বছর (যেমন ২০২৪ নয়, 2024)" className="rounded-lg border px-3 py-2"/>
      <button className="rounded-lg bg-emerald-800 px-5 py-2 font-semibold text-white">খুঁজুন</button>
    </form>
    {!dbReady ? <p className="mt-6 rounded-xl border border-amber-300 bg-amber-50 p-4 text-sm text-amber-900">ডেটাবেস সংযোগ বা migration প্রস্তুত নয়।</p> :
      rows.length===0 ? <p className="mt-6 rounded-xl border bg-white p-6 text-slate-600">এই অনুসন্ধানে যাচাইকৃত রায় পাওয়া যায়নি। নতুন রায় যাচাই শেষে এখানে প্রকাশিত হবে।</p> :
      <div className="mt-6 divide-y rounded-2xl border bg-white">{rows.map(c=><article key={c.id} className="p-5">
        <div className="flex flex-wrap gap-2 text-xs"><span className="rounded-full bg-slate-100 px-2 py-1">{c.courtDivision || c.court}</span><span className="rounded-full bg-emerald-50 px-2 py-1 text-emerald-800">{decisionLabels[c.decisionType || ''] || c.decisionType || 'সিদ্ধান্তের ধরন উল্লেখ নেই'}</span></div>
        <h2 className="mt-3 font-semibold"><Link href={`/cases/${c.slug}`} className="hover:underline">{c.caseTitle}</Link></h2>
        <p className="mt-1 text-sm text-slate-500">{c.caseNumber || 'মামলা নম্বর উল্লেখ নেই'} · {c.judgmentDate || 'রায়ের তারিখ উল্লেখ নেই'}</p>
        {c.summaryBn && <p className="mt-3 text-sm leading-6 text-slate-700">{c.summaryBn}</p>}
        <Link href={`/cases/${c.slug}`} className="mt-3 inline-block text-sm font-semibold text-emerald-800">রায়ের বিস্তারিত →</Link>
      </article>)}</div>
    }
  </main>;
}
