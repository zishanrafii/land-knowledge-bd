export default function GuidesPage() {
  return <main className="mx-auto min-h-screen max-w-5xl px-5 py-12"><a href="/" className="text-sm text-emerald-800">← হোম</a><h1 className="mt-5 text-3xl font-bold">ব্যবহারিক নির্দেশিকা</h1><p className="mt-3 text-slate-600">দলিল যাচাই, নামজারি, খতিয়ান, জমি কেনার আগে যাচাই ও অধিগ্রহণ-সংক্রান্ত সহায়ক নির্দেশিকা এখানে থাকবে।</p></main>;
}
