import Link from 'next/link';
import { BookOpen, Scale, FileCheck2, MapPinned, Calculator, Bell, Search, ShieldCheck } from 'lucide-react';

const features = [
  { title: 'আইন ও বিধিমালা', desc: 'মূল আইন, বিধি, সংশোধনী ও গেজেট', icon: BookOpen, href: '/laws' },
  { title: 'আদালতের রায়', desc: 'গুরুত্বপূর্ণ মামলা ও বিচারিক সিদ্ধান্ত', icon: Scale, href: '/cases' },
  { title: 'দলিল ও নামজারি', desc: 'দলিল যাচাই ও নামজারি-সংক্রান্ত তথ্য', icon: FileCheck2, href: '/guides' },
  { title: 'খতিয়ান ও জরিপ', desc: 'জরিপ, রেকর্ড ও মৌজা-সংক্রান্ত তথ্য', icon: MapPinned, href: '/guides' },
  { title: 'ফি ও ক্ষতিপূরণ', desc: 'আইনভিত্তিক ফি ও ক্ষতিপূরণ নির্দেশিকা', icon: Calculator, href: '/guides' },
  { title: 'আইন পরিবর্তনের খবর', desc: 'নতুন আইন, গেজেট ও সংশোধনী', icon: Bell, href: '/updates' },
];

export default function HomePage() {
  return (
    <main className="min-h-screen">
      <header className="bg-land-950 text-white">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-5">
          <Link href="/" className="flex items-center gap-3">
            <div className="grid h-11 w-11 place-items-center rounded-xl border border-land-gold text-land-gold"><Scale size={25}/></div>
            <div><div className="text-xl font-bold">ভূমি জ্ঞান</div><div className="text-xs tracking-wide text-emerald-100">LAND KNOWLEDGE BD</div></div>
          </Link>
          <nav className="flex items-center gap-4 text-sm text-emerald-50"><Link href="/laws">আইনভান্ডার</Link><Link href="/cases">মামলা</Link><button className="rounded-full border border-emerald-200/40 px-3 py-1.5">বাংলা / EN</button></nav>
        </div>
        <section className="mx-auto max-w-6xl px-5 pb-14 pt-10 md:pb-20 md:pt-16">
          <div className="max-w-3xl">
            <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-emerald-300/30 bg-white/5 px-3 py-1.5 text-sm text-emerald-100"><ShieldCheck size={16}/> সরকারি উৎসভিত্তিক আইনি তথ্যভান্ডার</div>
            <h1 className="text-3xl font-bold leading-tight md:text-5xl">জমি সম্পর্কে জানুন,<br/><span className="text-land-gold">অধিকার বুঝুন।</span></h1>
            <p className="mt-5 max-w-2xl text-base leading-7 text-emerald-50 md:text-lg">বাংলাদেশের ভূমি আইন, দলিল, রেকর্ড ও বিচারিক সিদ্ধান্তের তথ্য খুঁজুন এক জায়গায়। মূল উৎস ও যাচাইয়ের অবস্থা সঙ্গে নিয়েই।</p>
            <div className="mt-8 flex max-w-2xl items-center gap-3 rounded-2xl bg-white p-2 text-slate-700 shadow-xl">
              <Search className="ml-2 text-land-700" size={21}/><input aria-label="আইন খুঁজুন" className="min-w-0 flex-1 bg-transparent px-1 py-3 text-sm outline-none" placeholder="আইন, ধারা, মামলা বা বিষয় খুঁজুন..."/><button className="rounded-xl bg-land-700 px-5 py-3 text-sm font-semibold text-white">খুঁজুন</button>
            </div>
          </div>
        </section>
      </header>
      <section className="mx-auto max-w-6xl px-5 py-12 md:py-16">
        <div className="mb-7"><p className="text-sm font-semibold text-land-700">জ্ঞানভান্ডার</p><h2 className="mt-1 text-2xl font-bold md:text-3xl">আপনি কী খুঁজছেন?</h2><p className="mt-2 text-sm text-slate-600">বিষয় নির্বাচন করে আইন, রায় ও ব্যবহারিক নির্দেশিকা দেখুন।</p></div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {features.map(({title,desc,icon:Icon,href}) => <Link key={title} href={href} className="group rounded-2xl border border-slate-200 bg-white p-5 transition hover:-translate-y-1 hover:border-land-700/40 hover:shadow-lg"><div className="mb-4 grid h-12 w-12 place-items-center rounded-xl bg-land-100 text-land-700"><Icon size={24}/></div><h3 className="font-bold">{title}</h3><p className="mt-2 text-sm leading-6 text-slate-600">{desc}</p></Link>)}
        </div>
      </section>
      <section className="mx-auto max-w-6xl px-5 pb-14"><div className="flex flex-col gap-4 rounded-3xl border border-emerald-100 bg-emerald-50 p-6 md:flex-row md:items-center md:justify-between md:p-8"><div><h2 className="text-xl font-bold text-land-950">তথ্যের সঙ্গে থাকবে মূল উৎস</h2><p className="mt-2 max-w-2xl text-sm leading-6 text-slate-600">প্রতিটি আইনি নথির যাচাইয়ের অবস্থা, প্রকাশের তারিখ, সংশোধনী ও সরকারি উৎস আলাদাভাবে দেখানোর জন্য প্ল্যাটফর্মটি তৈরি হচ্ছে।</p></div><div className="flex items-center gap-2 text-sm font-semibold text-land-700"><ShieldCheck/> উৎস ও যাচাই-প্রথম নীতি</div></div></section>
      <footer className="border-t border-slate-200 bg-white"><div className="mx-auto max-w-6xl px-5 py-6 text-xs text-slate-500">© {new Date().getFullYear()} ভূমি জ্ঞান | Land Knowledge BD · তথ্য-সহায়ক প্ল্যাটফর্ম; ব্যক্তিগত আইনি পরামর্শের বিকল্প নয়।</div></footer>
    </main>
  );
}
