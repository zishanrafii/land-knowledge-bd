import pg from 'pg';
import bcrypt from 'bcryptjs';

const { Pool } = pg;
const email = process.env.ADMIN_EMAIL?.trim().toLowerCase();
const password = process.env.ADMIN_PASSWORD;
const databaseUrl = process.env.DATABASE_URL;
const sessionSecret = process.env.ADMIN_SESSION_SECRET;

if (!email || !password || !databaseUrl || !sessionSecret) {
  throw new Error('Set ADMIN_EMAIL, ADMIN_PASSWORD, DATABASE_URL and ADMIN_SESSION_SECRET.');
}
if (password.length < 14) throw new Error('ADMIN_PASSWORD must be at least 14 characters.');
if (sessionSecret.length < 32) throw new Error('ADMIN_SESSION_SECRET must be at least 32 characters.');

const pool = new Pool({ connectionString: databaseUrl });
try {
  const passwordHash = await bcrypt.hash(password, 12);
  await pool.query(
    `INSERT INTO admin_users (email, password_hash, role, is_active)
     VALUES ($1, $2, 'SUPER_ADMIN', TRUE)
     ON CONFLICT (email) DO UPDATE SET
       password_hash = EXCLUDED.password_hash,
       role = 'SUPER_ADMIN',
       is_active = TRUE,
       updated_at = NOW()`,
    [email, passwordHash],
  );
  console.log(`Super Admin ready: ${email}`);
} finally {
  await pool.end();
}
