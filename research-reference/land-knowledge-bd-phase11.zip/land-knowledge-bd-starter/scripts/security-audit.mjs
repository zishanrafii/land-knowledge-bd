import { readFileSync, existsSync } from 'node:fs';

const read = (file) => existsSync(file) ? readFileSync(file, 'utf8') : '';
const checks = [
  ['persistent login throttling table', 'src/db/schema.ts', /adminLoginAttempts/],
  ['login lockout logic', 'src/app/admin/login/actions.ts', /lockedUntil/],
  ['HTTPS-only URL validation', 'src/lib/validation.ts', /https:/],
  ['security headers middleware', 'src/middleware.ts', /Content-Security-Policy/],
  ['Super Admin final verification guard', 'src/app/admin/review/actions.ts', /admin\.role !== 'SUPER_ADMIN'/],
  ['case review final verification guard', 'src/app/admin/cases/review/actions.ts', /admin\.role !== 'SUPER_ADMIN'/],
  ['case metadata edit resets status to PENDING', 'src/app/admin/cases/actions.ts', /status:\s*'PENDING'/],
  ['case edit records a pending verification entry', 'src/app/admin/cases/actions.ts', /status:\s*'PENDING'[\s\S]*?checkedBy/],
  ['official source changes are transactional', 'src/app/admin/sources/actions.ts', /db\.transaction\(async \(tx\)/],
  ['adding a source resets legal document to PENDING', 'src/app/admin/sources/actions.ts', /status:\s*'PENDING'[\s\S]*?updatedAt/],
  ['source change records a fresh verification entry', 'src/app/admin/sources/actions.ts', /entityType:\s*'LEGAL_DOCUMENT'[\s\S]*?status:\s*'PENDING'/],
  ['Phase 9 SQL migration', 'drizzle/manual/0001_admin_security.sql', /CREATE TABLE IF NOT EXISTS admin_login_attempts/],
];

let failed = 0;
for (const [label, file, pattern] of checks) {
  const ok = pattern.test(read(file));
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${label}`);
  if (!ok) failed++;
}
if (failed) process.exitCode = 1;
else console.log(`\n${checks.length} static checks passed.`);
