## Phase 11 — official-source change integrity

- Adding a new official source (and optional attachment metadata) is now performed in one database transaction.
- The associated legal document is reset to `PENDING`, because a changed source set requires a fresh review.
- A new `LEGAL_DOCUMENT` verification-history entry records the source change.
- Static audit now checks transactional writes and review invalidation.
- This does not fetch, archive, checksum, or independently authenticate the linked source file.


## Phase 10 — case review integrity and validation

- Editing court-case metadata now resets the case's current status to `PENDING`.
- The verification history records the need for a fresh review after metadata changes.
- `npm run security:audit` checks the pending-reset behavior in addition to the Phase 9 security controls.
- The static audit is not a substitute for database migration execution, integration tests, or production security review.

# ভূমি জ্ঞান | Land Knowledge BD

A starter web application for a bilingual Bangladesh land-law information platform.

## Stack
- Next.js App Router + TypeScript
- Tailwind CSS
- PostgreSQL + Drizzle ORM
- Zod validation

## Requirements
- Node.js 20.9+
- PostgreSQL 15+

## Setup
1. Install dependencies:
   ```bash
   npm install
   ```
2. Copy `.env.example` to `.env` and set `DATABASE_URL`.
3. Generate and run migrations:
   ```bash
   npm run db:generate
   npm run db:migrate
   ```
4. Start development:
   ```bash
   npm run dev
   ```

Open http://localhost:3000.

## Important
This is a development scaffold, not a complete legal service. Sample UI content is illustrative. Legal documents must be added from official sources and verified before being marked `VERIFIED`.


## Phase 7 — Court Judgment Library
- Public `/cases` search supports case title/number/summary, court division, decision type, and year.
- Public `/cases/[slug]` detail pages show metadata, verified source links, attachments, judgment text, and related legal documents/sections.
- Only `VERIFIED` cases are visible publicly.
- Added `case_attachments`, `case_sources`, and `case_legal_links` tables, and expanded `court_cases` metadata.
- Case records remain unseeded; no judgments are invented or published as examples.

### Migration note
The schema has changed. Run `npm run db:generate` and review the generated SQL before `npm run db:migrate`. For an existing database, back up first. Existing `court_cases` rows will need a unique `slug` populated before applying the new NOT NULL constraint; do not run the migration blindly on a database with existing case rows.

## Phase 8 — Admin access and case-law workflow

This phase adds:
- Database-backed admin accounts with `SUPER_ADMIN`, `EDITOR`, and `REVIEWER` roles.
- Eight-hour HTTP-only, SameSite=Strict session cookies; active account and role are rechecked from the database.
- Admin login/logout and a protected dashboard.
- Super Admin bootstrap script (`npm run admin:create`).
- Court-case intake, metadata editing, internal research notes, and a separate review queue.
- Only Super Admin can set final `VERIFIED`, `INCORRECT_REPLACED`, or `DUPLICATE` states.

### Database migration

After setting `DATABASE_URL` and installing dependencies, generate and apply the schema migration:

```bash
npm install
npx drizzle-kit generate
npm run db:migrate
```

Set `ADMIN_EMAIL`, `ADMIN_PASSWORD` (at least 14 characters), and
`ADMIN_SESSION_SECRET` (at least 32 characters) in the environment, then run:

```bash
npm run admin:create
```

### Important limitations before production

- This phase has not been built, type-checked, migrated, or security-tested against a live database in this environment.
- Add login rate limiting, security monitoring, backup/restore tests, and deployment secrets management before public launch.
- Case PDF/source fields store URL metadata only; they do not upload, scan, archive, or checksum files.
- Legal content remains empty until primary documents and judgments are individually collected and verified.
- Do not treat an entered URL or an admin-created record as legally verified by itself.


## Phase 9 — Security hardening

This phase adds:
- Persistent per-email login throttling: five failed attempts within a 15-minute window trigger a 15-minute lock.
- HTTPS-only validation for legal source links, case judgment links, and case attachments.
- Re-review invalidation when court-case metadata is edited (the case returns to `PENDING`).
- Super Admin protection against changing already-finalized legal-document and case statuses.
- Baseline security response headers, including CSP, frame protection, MIME sniffing protection, and production HSTS.
- A static source audit command: `npm run security:audit`.

### Phase 9 database migration

Back up the database first. This additive SQL migration assumes the Phase 8 core schema is already installed, including the `court_cases` table:

```bash
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f drizzle/manual/0001_admin_security.sql
```

The migration creates/ensures the admin role enum, admin users, internal case research notes, and login-attempt table. If your database has a different or partial schema, inspect the SQL and reconcile it before running.

### Validation and production cautions

Run `npm run security:audit`, `npm run lint`, and `npm run build` after installing dependencies. Rehearse the migration on a database backup and test role permissions, login lockout, session expiry, and case re-verification before production.

The login throttle is per email address, not per IP/device; add reverse-proxy/WAF rate limiting for public deployment. Review the Content Security Policy when adding external fonts, analytics, embeds, or image hosts. Security headers and static checks do not constitute a penetration test.

This remains a development scaffold. No legal corpus, scanned judgments, PDF upload pipeline, malware scanning, file hashing, or production deployment is included. No build or database migration has been run in this environment.
