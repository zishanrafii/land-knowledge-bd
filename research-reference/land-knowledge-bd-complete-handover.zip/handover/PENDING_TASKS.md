# Pending Tasks / Next Work Queue

## Priority 0 — recover the evidence base
1. Recover all 22 research batch outputs and the L001–L446 mapping.
2. Recover detailed Audits 04–10; preserve original wording and source references.
3. Create `RESEARCH_LEDGER.csv` (one row per legal instrument/document) and `AUDIT_MATRIX.csv` (one row per claim/check).
4. Deduplicate records with canonical IDs and cross-reference duplicate rows.
5. Calculate verified/pending totals only after ledger reconstruction.

## Priority 1 — high-risk legal verification
1. Full clause-by-clause audit of the 155-page Immovable Property Acquisition and Requisition Rules 2026; resolve 22/29 July date discrepancy.
2. Full 21-page Land Crime Rules 2024 audit including forms and schedules.
3. Full 23-page BSCIC 2023 policy clause audit.
4. Full amendment chronologies for State Acquisition and Tenancy, Registration, Transfer of Property and Stamp Acts.
5. Land Reforms Act 2023 rules/forms.
6. Jalmahal, sairat mahal, khas land and lease policies.
7. Premises Rent Control Act 1991 (historical Audit item 30).
8. Audit items 35, 36, 46, 47 — recover exact titles from missing inventory.
9. Antiquities Rules 1986, forestry laws/rules/transitions.
10. Railway Act/rules, 2010 unused-land memo, road/electricity/BWDB project acquisition/ROW/easement instruments.
11. CHT Rule 34, Standing Orders, amendments/procedures/GIS/implementation.
12. River/wetland judgments, 2024 Jalmahal amendment, 2026 Haor rules.
13. District Gazettes, mouza maps, delegation notices and protected boundaries.
14. Court PDFs with case number, court/bench/date, final/interim status, operative orders and later appeals/stays/modifications.

## Priority 2 — web app development
1. Resume from Phase 11 ZIP and inspect Phase 12 worktree snapshot.
2. Validate SQL migrations on a disposable PostgreSQL database.
3. Install dependencies; run typecheck, lint, tests and production build.
4. Reconcile Drizzle schema with manual SQL migration files.
5. Implement import workflow from verified legal ledger.
6. Build search, document detail, version timeline, source/attachment display, bilingual UI and reviewer workflow.
7. Add automated tests for verification resets, role restrictions, URL validation and admin lockout.
8. Deploy only after security review, backups and migration rehearsal.

## Weekly monitoring
An existing automation is configured:
- Title: সাপ্তাহিক ভূমি আইন আপডেট পর্যবেক্ষণ
- Schedule: Mondays 12:45 Bangladesh time (Asia/Dhaka)
- Automation ID: `Automation_1c72f8eb259481918c519ec0e0c0ea58`
Do not recreate it. Review each alert against the original government document.
