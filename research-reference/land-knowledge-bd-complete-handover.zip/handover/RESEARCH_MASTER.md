# Research Master — Recovered Research Notes

## Scope
Bangladesh land and land-related legal materials: primary statutes, rules, amendments, ordinances, gazettes, circulars, policies, administrative orders and published relevant higher-court decisions.

## Important evidence limitation
Historical context indicates 22/22 research batches were presented and an inventory range L001–L446 existed. This does **not** establish that all 446 items were verified. The full row-level inventory and complete Audit 04–10 details were not recovered. Treat the notes below as leads and partial findings, not a certified legal register.

## Audit 01 — foundational laws
Ten laws were identified; none was fully verified for current consolidated text and all amendments in the recovered notes:
1. State Acquisition and Tenancy Act, 1950
2. Non-Agricultural Tenancy Act, 1949
3. Transfer of Property Act, 1882
4. Registration Act, 1908
5. Stamp Act, 1899
6. Specific Relief Act, 1877
7. Limitation Act, 1908
8. Partition Act, 1893
9. Easements Act, 1882
10. Survey Act, 1875

## Audit 02 — personal law, inheritance, waqf, abandoned/vested property, CHT
Twelve distinct entries were examined; eight official title/list identifications and four full text/amendment checks were still pending. Identification is not full verification.

Recovered leads:
- Muslim Personal Law (Shariat) Application Act, 1937
- Succession Act, 1925
- Hindu Women’s Rights to Property Act, 1937
- Hindu Inheritance (Removal of Disabilities) Act, 1928
- Waqfs Ordinance, 1962 (Ordinance I of 1962)
- Waqf (Transfer and Development of Property) Act, 2013 — recorded as Act No. 5 of 2013; date recorded 2013-02-24
- Bangladesh Abandoned Property Order, 1972 — recorded as President’s Order No. 16 of 1972; date recorded 1972-02-28
- Vested Property Return Act, 2001 — recorded as Act No. 16 of 2001; date recorded 2001-04-11
- CHT Land Dispute Commission Act, 2001 — recorded as Act No. 53 of 2001; date recorded 2001-07-17; duplicate noted in Batch 22
- A 2016 amendment to the CHT Act was also mentioned.

Required: verify official titles/numbers/dates, amendment chronology, commencement, current status, original Gazette/text and duplicates.

## Audit 03 — survey, khatian, mutation, land crime, khas land
Recovered leads:
- State Acquisition and Tenancy Act, 1950: sections 143, 143B, 143C, 144, 144A, 145A, 145B, 145F.
- ভূমি অপরাধ প্রতিরোধ ও প্রতিকার আইন, ২০২৩ — recorded as আইন নং 36/2023; date recorded 2023-09-18.
- ভূমি অপরাধ প্রতিরোধ ও প্রতিকার বিধিমালা, ২০২৪ — recorded as S.R.O. 371-Law/2024; date recorded 2024-10-24.
- Recovery of Possession Ordinance, 1970 — original text/Gazette identified; rules-based full verification pending.
Historical count was described as four main laws/ordinances plus one Gazette/document entry; reconcile against the missing ledger.

## Audit 11 — Chittagong Hill Tracts
Leads:
- Chittagong Hill Tracts Regulation, 1900
- Rules for Administration of CHT
- 2003 amendment
- Three Hill District Council Acts, 1989
- Regional Council Act, 1998
- CHT Land Disputes Commission Act, 2001 and 2016 amendment
- USF / VCF materials
Original sources were said to be identified, but Rule 34, Standing Orders, amendments, procedures, GIS and implementation remained pending. Historical grouping was “1+3+1+2”; exact row mapping unavailable.

## Audit 12 — acquisition, requisition, railways, project land
Leads:
- Acquisition and Requisition of Immovable Property Act, 2017.
- Immovable Property Acquisition and Requisition Rules, 2026 — recorded as SRO 286-Law/2026.
- 2026 financial guideline.
- Railway Act, 1890.
- Project-specific policies.
The 2017 Act original text and sections 9–14, 19, 30, 36–37 were reported checked. Full 155-page audit of the 2026 Rules remained pending. A Gazette date discrepancy of 22 July vs 29 July 2026 was recorded and must be resolved from the original Gazette. 2010 unused-land memo, railway, road/electricity/BWDB project rules, ROW/easement remained pending or partial.

## Audit 13 — rivers, wetlands, alluvion/diluvion, water, jalmahal
Leads:
- State Acquisition and Tenancy Act, 1950 sections 86–87.
- Alluvion and Diluvion Regulation, 1825.
- Alluvial Lands Act, 1920.
- Bangladesh Water Act, 2013.
- A record called “Haor/Wetland Act, 2026” — exact official title/number requires primary-source confirmation.
- Jalmahal Policy 2009/2012.
- Embankment and Drainage Act, 1952.
- Bangladesh River Protection Commission Act, 2013.
Pending: river judgments, 2024 Jalmahal amendment, 2026 Haor implementation rules; verify exact names/numbers/current status.

## 2026 legal leads requiring primary-source revalidation
These are **not certified facts**:
- Land Use Control and Agricultural Land Protection Act, 2026 — recorded as Act 50; date 2026-04-10; said to replace Ordinance 12. Verify exact title, number, commencement, repeal and savings.
- Immovable Property Acquisition and Requisition Rules, 2026 — SRO 286-Law/2026; resolve Gazette date discrepancy (22/29 July).
- Registration (Amendment) Act, 2026 — recorded as Act 14; details unconfirmed.
- Transfer of Property (Amendment) Act, 2026 — recorded as Act 105; date recorded 2026-09-08; sections 122A/122B flagged.
Do not publish these as current law until checked against original government documents.

## Research method for every record
Capture: canonical title, Bangla title, instrument type, number/year, issuing authority, Gazette number/date/page, publication date, commencement date, territorial scope, amendment/repeal history, section-level effect, related instruments, official source URL, attachment checksum, verification date, reviewer, confidence/status.
