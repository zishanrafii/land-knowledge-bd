# ভূমি জ্ঞান | Land Knowledge BD — Handover Package

এই প্যাকেজটি অন্য ChatGPT account বা নতুন development session-এ কাজ চালিয়ে যাওয়ার জন্য তৈরি।

## প্রথমে যা বুঝতে হবে
- এটি **web app only** প্রকল্প; native Android/iOS app নয়।
- প্রকল্পের লক্ষ্য বাংলাদেশের ভূমি ও ভূমিসংশ্লিষ্ট আইন, বিধি, গেজেট, নীতিমালা, পরিপত্র এবং প্রাসঙ্গিক আদালতের সিদ্ধান্তের bilingual (বাংলা/English) knowledge platform।
- আগের গবেষণার কিছু সারাংশ উদ্ধার করা গেছে, কিন্তু সম্পূর্ণ row-level audit ledger উদ্ধার হয়নি।
- ২২/২২টি research batch উপস্থাপিত হয়েছিল—এটি ১০০% আইন যাচাই হয়েছে, এমন দাবি নয়।
- L001–L446 inventory-এর সম্পূর্ণ item mapping এবং Audit 04–10-এর পূর্ণ বিবরণ অনুপস্থিত। এগুলো পুনরুদ্ধার/পুনর্গঠন করতে হবে।
- এই প্যাকেজে Phase 11 ZIP থাকলে সেটি সর্বশেষ যাচাইকৃত ZIP। Phase 12-এর কিছু কাজ workspace-এ ছিল, কিন্তু ZIP তৈরি/পরীক্ষা সম্পন্ন হয়নি।

## প্যাকেজের ফাইল
- `PROJECT_MASTER.md` — পণ্যের লক্ষ্য ও নীতিমালা
- `RESEARCH_MASTER.md` — উদ্ধারকৃত গবেষণা সারাংশ
- `AUDIT_STATUS.md` — অডিটের অবস্থা ও সীমাবদ্ধতা
- `PENDING_TASKS.md` — পরবর্তী কাজ
- `SOURCE_REGISTER.md` — প্রাথমিক সরকারি উৎসের তালিকা
- `CHANGELOG.md` — কোডের Phase 9–12 অবস্থা
- `NEXT_ACCOUNT_PROMPT.md` — নতুন account-এ ব্যবহারযোগ্য নির্দেশনা
- `land-knowledge-bd-phase11.zip` — Phase 11 code snapshot (যদি সংযুক্ত থাকে)
- `phase12-work-in-progress/` — Phase 12-এর উদ্ধারযোগ্য source snapshot (যদি পাওয়া যায়)

## নতুন account-এ কাজ শুরুর নিয়ম
1. পুরো ZIP upload করুন।
2. `NEXT_ACCOUNT_PROMPT.md`-এর নির্দেশনা দিন।
3. প্রথম কাজ হবে এই handover-এর তথ্য যাচাই করে একটি durable `RESEARCH_LEDGER.csv` ও `AUDIT_MATRIX.csv` তৈরি করা।
4. কোনো আইন/তারিখ/নম্বরকে verified বলার আগে মূল সরকারি নথি খুলে যাচাই করতে হবে।
5. অজানা তথ্যকে অনুমান করে পূরণ করা যাবে না।
