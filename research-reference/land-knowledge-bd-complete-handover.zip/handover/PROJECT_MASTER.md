# Project Master — ভূমি জ্ঞান | Land Knowledge BD

## Product definition
A Bangladesh-focused, bilingual Bangla/English web knowledge platform covering land and land-related law. Web app only.

## Core goals
- Search and browse Bangladesh land laws, rules, regulations, amendments, ordinances, gazettes, notifications, circulars, policies, official orders and relevant higher-court decisions.
- Show official source links and attach original PDFs/documents where legally and technically possible.
- Explain legal provisions in accessible Bangla and English while distinguishing explanation from authoritative legal text.
- Support Bangla/English language switching and light/dark themes.
- Provide attractive, accessible UI, original branding/logo and appropriate AI-generated visual assets.
- Maintain update history and a weekly monitoring workflow.

## Data integrity principles
1. Separate legal instrument types: Act, Ordinance, Rule, Regulation, Gazette, Notification, Circular, Policy, Administrative Order, Judgment.
2. Store publication date, commencement/effective date, verification date separately.
3. Preserve previous versions; never overwrite historical text.
4. Record amendments, repeals, savings, transitional provisions and section-level effective dates.
5. Every legal record must have source provenance. Prefer the original official Gazette or official consolidated law.
6. Distinguish `VERIFIED`, `PARTIALLY_VERIFIED`, `PENDING`, `INCORRECT_REPLACED`, and `DUPLICATE`.
7. A search result, title listing, cached page or secondary commentary alone is not proof of current law.
8. Do not claim comprehensive coverage until the coverage matrix and row-level evidence are complete.
9. Provide a clear disclaimer: educational information, not a substitute for advice from a qualified Bangladesh lawyer.

## Suggested data model
LegalDocument, LegalDocumentVersion, LegalSection, OfficialSource, Amendment, CourtCase, Attachment, RelatedLink, VerificationRecord, Category, SourceAttachment.

## Current technical direction
- Next.js 15
- TypeScript
- Tailwind CSS
- PostgreSQL
- Drizzle ORM
- Zod
- bcryptjs
- jose

## Product features to build
- Homepage with search and category navigation
- Law/document detail pages with section navigation
- Bangla/English toggle
- Light/dark theme
- Amendment timeline and historical versions
- Official source + attachment panel
- Court judgment library with case metadata and operative outcome
- Admin/reviewer workflow and verification history
- Search filters by instrument type, year, topic, status and jurisdiction
- Weekly update log
- Responsive web UI

## Security and review requirements
- Admin login protections and persistent lockout
- HTTPS-only external source links
- Strong CSP/security headers
- Role-based verification; only authorized Super Admin can finalize verification
- Any substantive edit to a verified record must reset it to PENDING and create an audit-history record
- Manual SQL migrations must be reviewed and backed up before production use
