# Official Source Register

Use primary government sources first. A homepage or search listing is a discovery point, not proof of a legal claim. Save the exact document URL, Gazette issue/page, download date and file hash.

| Source | Primary use | URL |
|---|---|---|
| Laws of Bangladesh / Legislative Division | Acts, ordinances, consolidated laws | https://bdlaws.minlaw.gov.bd/ |
| Ministry of Land | Ministry notices, policies, circulars, land administration | https://minland.gov.bd/ |
| Department of Land Records and Surveys (DLRS) | Survey, records, maps, land measurement materials | https://dlrs.gov.bd/ |
| Bangladesh Government Press / DPP | Official Gazette and SRO/notifications | https://www.dpp.gov.bd/ |
| Supreme Court of Bangladesh | Published judgments, cause lists and court information | https://www.supremecourt.gov.bd/ |
| Law and Justice Division | Legal and judicial administration notices | https://lawjusticediv.gov.bd/ |

## Source handling rules
- Open the original official document, not merely a search result snippet.
- Preserve the original PDF/file and record its checksum.
- Record Gazette publication date separately from commencement/effective date.
- If a government site is unavailable, mark `PENDING` and retry; do not silently substitute a third-party copy.
- Secondary sources may help discovery or interpretation but cannot independently establish a statute's official text or current status.
