# Prompt for the next ChatGPT account

You are continuing an existing project: **ভূমি জ্ঞান | Land Knowledge BD**.

Read every file in this handover package before making changes. The project is a Bangladesh land-law **web app only**, bilingual Bangla/English. The goal is a trustworthy, source-linked knowledge base for land laws, rules, amendments, gazettes, circulars, policies and relevant higher-court decisions.

## Critical honesty requirements
- Historical notes say 22/22 research batches were presented and the inventory range was L001–L446. This does NOT mean all records were verified.
- Audit 04–10 detailed outputs and the complete L001–L446 row mapping are missing from the recovered context.
- Do not invent an audit count, completion percentage, source URL, legal title, Act/SRO number, publication date or commencement date.
- Treat the 2026 legal leads in `RESEARCH_MASTER.md` as unverified until checked against original government documents.
- Never mark a record VERIFIED based only on search snippets, secondary websites or a title listing.
- Clearly separate title identification from full text/current-amendment verification.

## First actions
1. Inspect the included Phase 11 ZIP and any Phase 12 source snapshot.
2. Produce a file inventory and report exactly which files are present/missing.
3. Rebuild `RESEARCH_LEDGER.csv` and `AUDIT_MATRIX.csv`; preserve provenance and status.
4. Recover missing Audit 04–10 and L001–L446 records from available project files/conversation artifacts where possible.
5. Revalidate high-risk legal leads using official primary sources.
6. Continue app development in parallel; do not wait for the entire legal corpus to be finished before building the data model and UI.
7. Run tests/typecheck/build/DB migration validation and report precisely what passed and failed.

## Status vocabulary
Use only: VERIFIED, PARTIALLY_VERIFIED, PENDING, INCORRECT_REPLACED, DUPLICATE.

## User experience requirements
- Attractive responsive web app, not native mobile app.
- Bangla and English language toggle.
- Light/dark theme.
- Official source links and original attachments wherever possible.
- Historical version and amendment timeline.
- Admin/reviewer workflow with verification history.
- Original logo and suitable AI-generated visuals when needed.
- Explain legal content accessibly and include a legal-information disclaimer.

## Working style
The user often says “Next” to mean continue the next concrete task. Give visible progress with evidence-based counts. If a file cannot be generated or a build cannot be run, say so plainly and do not claim completion.
